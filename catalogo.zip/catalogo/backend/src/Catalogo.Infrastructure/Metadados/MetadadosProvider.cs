using System.Text.Json;
using Catalogo.Application.Abstracoes;
using Catalogo.Domain.Metadados;
using Catalogo.Infrastructure.Persistencia;
using Catalogo.Infrastructure.Persistencia.Tabelas;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Catalogo.Infrastructure.Metadados;

/// <summary>
/// Lê os metadados de um grupo do banco e guarda em cache (IMemoryCache) por
/// <see cref="TempoCache"/>. Metadados mudam pouco e são lidos em toda requisição.
///
/// Cada servidor tem o seu cache. Ao alterar metadados direto no banco (script V00x),
/// o valor novo aparece em até <see cref="TempoCache"/> ou depois de reiniciar a aplicação.
/// Quando existir edição de metadados pela aplicação, ela deve chamar <see cref="InvalidarCache"/>.
/// </summary>
internal sealed class MetadadosProvider(CatalogoDbContext contexto, IMemoryCache cache) : IMetadadosProvider
{
    public static readonly TimeSpan TempoCache = TimeSpan.FromMinutes(10);

    public async Task<Grupo?> ObterGrupoAsync(string grupoChave, CancellationToken cancellationToken)
    {
        var chaveCache = ChaveCache(grupoChave);
        if (cache.TryGetValue(chaveCache, out Grupo? grupoEmCache))
            return grupoEmCache;

        var grupo = await CarregarGrupoAsync(grupoChave, cancellationToken);

        // Grupo inexistente não vai para o cache: se for criado depois, aparece na hora.
        if (grupo is not null)
            cache.Set(chaveCache, grupo, TempoCache);

        return grupo;
    }

    public void InvalidarCache(string grupoChave) => cache.Remove(ChaveCache(grupoChave));

    // A collation do banco não diferencia maiúsculas, então o cache também não.
    private static string ChaveCache(string grupoChave) => $"catalogo:metadados:grupo:{grupoChave.ToLowerInvariant()}";

    private async Task<Grupo?> CarregarGrupoAsync(string grupoChave, CancellationToken cancellationToken)
    {
        // Consultas simples, uma por tabela, em vez de Includes encadeados.
        var grupo = await contexto.Grupos.AsNoTracking()
            .FirstOrDefaultAsync(g => g.Chave == grupoChave, cancellationToken);
        if (grupo is null)
            return null;

        var entidades = await contexto.Entidades.AsNoTracking()
            .Where(e => e.GrupoId == grupo.Id)
            .ToListAsync(cancellationToken);
        var entidadeIds = entidades.Select(e => e.Id).ToList();

        var campos = await contexto.Campos.AsNoTracking()
            .Where(c => entidadeIds.Contains(c.EntidadeId))
            .ToListAsync(cancellationToken);
        var campoIds = campos.Select(c => c.Id).ToList();

        var restricoes = await contexto.RestricoesUnicas.AsNoTracking()
            .Where(r => entidadeIds.Contains(r.EntidadeId))
            .ToListAsync(cancellationToken);

        var restricoesCampos = await contexto.RestricoesUnicasCampos.AsNoTracking()
            .Where(rc => entidadeIds.Contains(rc.EntidadeId))
            .ToListAsync(cancellationToken);

        var dependencias = await contexto.CamposDependencias.AsNoTracking()
            .Where(d => campoIds.Contains(d.CampoId))
            .ToListAsync(cancellationToken);

        // Uma dependência pode citar campos de entidades de outro grupo: carrega esses também.
        var idsDeOutrosGrupos = dependencias
            .SelectMany(d => new[] { d.CampoViaId, d.CampoOrigemId, d.CampoAlvoId })
            .OfType<Guid>()
            .Except(campoIds)
            .ToList();
        if (idsDeOutrosGrupos.Count > 0)
        {
            campos.AddRange(await contexto.Campos.AsNoTracking()
                .Where(c => idsDeOutrosGrupos.Contains(c.Id))
                .ToListAsync(cancellationToken));
        }

        var montado = MontarGrupo(grupo, entidades, campos, restricoes, restricoesCampos, dependencias);

        // RN14: falha com mensagem clara se algum campo usa chave reservada (erro de configuração).
        ChavesReservadas.ValidarCampos(montado);
        return montado;
    }

    /// <summary>Converte as linhas das tabelas no modelo de leitura imutável do Domain.</summary>
    private static Grupo MontarGrupo(
        GrupoTabela grupo,
        List<EntidadeTabela> entidades,
        List<CampoTabela> campos,
        List<RestricaoUnicaTabela> restricoes,
        List<RestricaoUnicaCampoTabela> restricoesCampos,
        List<CampoDependenciaTabela> dependencias)
    {
        var camposPorId = campos.Select(ParaDominio).ToDictionary(c => c.Id);

        var dependenciasDominio = dependencias
            .Select(d => new CampoDependencia
            {
                Campo = camposPorId[d.CampoId],
                CampoVia = d.CampoViaId is Guid viaId ? camposPorId[viaId] : null,
                CampoOrigem = camposPorId[d.CampoOrigemId],
                CampoAlvo = camposPorId[d.CampoAlvoId],
            })
            .ToList();

        var restricoesDominio = restricoes
            .Select(r => new RestricaoUnica
            {
                Id = r.Id,
                EntidadeId = r.EntidadeId,
                Nome = r.Nome,
                // RestricaoUnicaCampo não tem coluna de ordem: a ordem do hash é Campo.Ordem e depois Chave.
                Campos = OrdenarCampos(restricoesCampos
                    .Where(rc => rc.RestricaoUnicaId == r.Id)
                    .Select(rc => camposPorId[rc.CampoId])),
            })
            .ToList();

        return new Grupo
        {
            Id = grupo.Id,
            Chave = grupo.Chave,
            Nome = grupo.Nome,
            Descricao = grupo.Descricao,
            Entidades = entidades
                .Select(e => new Entidade
                {
                    Id = e.Id,
                    GrupoId = e.GrupoId,
                    Chave = e.Chave,
                    Nome = e.Nome,
                    Descricao = e.Descricao,
                    CampoExibicaoId = e.CampoExibicaoId,
                    EscopoEquipe = e.EscopoEquipe,
                    Campos = OrdenarCampos(camposPorId.Values.Where(c => c.EntidadeId == e.Id)),
                    RestricoesUnicas = restricoesDominio.Where(r => r.EntidadeId == e.Id).OrderBy(r => r.Nome, StringComparer.Ordinal).ToList(),
                    Dependencias = dependenciasDominio.Where(d => d.Campo.EntidadeId == e.Id).ToList(),
                })
                .ToList(),
        };
    }

    private static List<Campo> OrdenarCampos(IEnumerable<Campo> campos) =>
        campos.OrderBy(c => c.Ordem).ThenBy(c => c.Chave, StringComparer.Ordinal).ToList();

    private static Campo ParaDominio(CampoTabela campo) => new()
    {
        Id = campo.Id,
        EntidadeId = campo.EntidadeId,
        Chave = campo.Chave,
        Nome = campo.Nome,
        TipoDado = campo.TipoDado,
        Obrigatorio = campo.Obrigatorio,
        TamanhoMaximo = campo.TamanhoMaximo,
        Precisao = campo.Precisao,
        Escala = campo.Escala,
        Opcoes = LerOpcoes(campo),
        EntidadeReferenciadaId = campo.EntidadeReferenciadaId,
        AcaoExclusao = campo.AcaoExclusao,
        Ordem = campo.Ordem,
        Ativo = campo.Ativo,
    };

    /// <summary>Campo.Opcoes é um array JSON de textos (o CHECK do banco só garante que é JSON válido).</summary>
    private static IReadOnlyList<string> LerOpcoes(CampoTabela campo)
    {
        if (string.IsNullOrWhiteSpace(campo.Opcoes))
            return [];

        try
        {
            return JsonSerializer.Deserialize<List<string>>(campo.Opcoes) ?? [];
        }
        catch (JsonException ex)
        {
            throw new InvalidOperationException(
                $"Campo '{campo.Chave}' ({campo.Id}): Opcoes precisa ser um array JSON de textos, ex.: [\"GET\",\"POST\"].", ex);
        }
    }
}

using Catalogo.Domain.Acesso;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Catalogo.Infrastructure.Persistencia.Configuracoes;

/// <summary>dbo.Equipe — espelha database/scripts/V003__usuarios_equipes_historico.sql.</summary>
internal sealed class EquipeConfiguracao : IEntityTypeConfiguration<Equipe>
{
    public void Configure(EntityTypeBuilder<Equipe> builder)
    {
        builder.ToTable("Equipe");

        builder.HasKey(e => e.Id).HasName("PK_Equipe");
        builder.HasAlternateKey(e => e.Nome).HasName("UQ_Equipe_Nome");

        // Gerado pelo EF ao adicionar (GUID sequencial), para o histórico usar o Id antes do SaveChanges.
        builder.Property(e => e.Id).HasColumnType("uniqueidentifier").ValueGeneratedOnAdd();
        builder.Property(e => e.Nome).HasColumnType("nvarchar(150)").IsRequired();
        builder.Property(e => e.Ativa).HasColumnType("bit").HasDefaultValue(true);
        builder.Property(e => e.CriadoEm).HasColumnType("datetime2").HasDefaultValueSql("SYSUTCDATETIME()")
            .HasConversion(ConversoresUtc.Data);
    }
}

using Catalogo.Application.Abstracoes;
using Catalogo.Domain.Excecoes;
using Microsoft.EntityFrameworkCore;

namespace Catalogo.Infrastructure.Persistencia;

/// <summary>
/// Grava tudo num único SaveChanges (uma transação) e traduz os erros do banco
/// para exceções que a Application entende.
/// </summary>
internal sealed class UnidadeDeTrabalho(CatalogoDbContext contexto) : IUnidadeDeTrabalho
{
    public async Task SalvarAlteracoesAsync(CancellationToken cancellationToken)
    {
        try
        {
            await contexto.SaveChangesAsync(cancellationToken);
        }
        // DbUpdateConcurrencyException herda de DbUpdateException, por isso vem primeiro.
        catch (DbUpdateConcurrencyException ex)
        {
            throw new ConflitoConcorrenciaException(
                "O registro foi alterado por outra pessoa depois que você o leu. Recarregue e tente de novo.", ex);
        }
        catch (DbUpdateException ex) when (TradutorErrosSqlServer.EhViolacaoUnicidade(ex, out var restricaoUnicaId))
        {
            throw new ViolacaoUnicidadeBancoException(restricaoUnicaId, ex);
        }
    }
}

using Catalogo.Domain.Metadados;

namespace Catalogo.Infrastructure.Persistencia.Tabelas;

// Classes que espelham as tabelas de METADADOS, coluna por coluna (ver database/scripts/V001).
// Elas só existem para o EF ler o banco: o MetadadosProvider converte para o modelo de leitura
// imutável do Domain (Grupo, Entidade, Campo...), que é o que o resto da aplicação usa.
// Por isso ficam na Infrastructure e com o sufixo "Tabela".

/// <summary>dbo.Grupo</summary>
public sealed class GrupoTabela
{
    public Guid Id { get; set; }
    public string Chave { get; set; } = "";
    public string Nome { get; set; } = "";
    public string? Descricao { get; set; }
    public DateTime CriadoEm { get; set; }
}

/// <summary>dbo.Entidade</summary>
public sealed class EntidadeTabela
{
    public Guid Id { get; set; }
    public Guid GrupoId { get; set; }
    public string Chave { get; set; } = "";
    public string Nome { get; set; } = "";
    public string? Descricao { get; set; }
    public Guid? CampoExibicaoId { get; set; }

    /// <summary>1 = registros por equipe; 0 = registros globais (V003).</summary>
    public bool EscopoEquipe { get; set; } = true;

    public DateTime CriadoEm { get; set; }
}

/// <summary>dbo.Campo</summary>
public sealed class CampoTabela
{
    public Guid Id { get; set; }
    public Guid EntidadeId { get; set; }
    public string Chave { get; set; } = "";
    public string Nome { get; set; } = "";

    /// <summary>Convertido de/para o texto do banco ("TEXTO", "DATA_HORA"...) na configuração do EF.</summary>
    public TipoDado TipoDado { get; set; }

    public bool Obrigatorio { get; set; }
    public int? TamanhoMaximo { get; set; }
    public byte? Precisao { get; set; }
    public byte? Escala { get; set; }

    /// <summary>Array JSON de textos, ex.: ["GET","POST"]. Convertido em lista pelo MetadadosProvider.</summary>
    public string? Opcoes { get; set; }

    public Guid? EntidadeReferenciadaId { get; set; }
    public AcaoExclusao? AcaoExclusao { get; set; }
    public int Ordem { get; set; }
    public bool Ativo { get; set; }
    public DateTime CriadoEm { get; set; }
}

/// <summary>dbo.CampoDependencia</summary>
public sealed class CampoDependenciaTabela
{
    public Guid CampoId { get; set; }
    public Guid? CampoViaId { get; set; }
    public Guid CampoOrigemId { get; set; }
    public Guid CampoAlvoId { get; set; }
}

/// <summary>dbo.RestricaoUnica</summary>
public sealed class RestricaoUnicaTabela
{
    public Guid Id { get; set; }
    public Guid EntidadeId { get; set; }
    public string Nome { get; set; } = "";
}

/// <summary>dbo.RestricaoUnicaCampo</summary>
public sealed class RestricaoUnicaCampoTabela
{
    public Guid RestricaoUnicaId { get; set; }
    public Guid EntidadeId { get; set; }
    public Guid CampoId { get; set; }
}

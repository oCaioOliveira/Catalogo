# AGENTS.md — Catalogo.Infrastructure

Complementa o [`AGENTS.md` da raiz](../../AGENTS.md).

## O que fica aqui

| Caminho | Conteúdo |
|---|---|
| `Persistencia/CatalogoDbContext.cs` | o `DbContext` |
| `Persistencia/Configuracoes/` | **uma classe `IEntityTypeConfiguration` por tabela**, espelhando o script SQL |
| `Persistencia/Tabelas/` | classes que espelham as tabelas de metadados (sufixo `Tabela`) |
| `Persistencia/UnidadeDeTrabalho.cs` | `SaveChanges` e tradução de erros do banco |
| `Persistencia/TradutorErrosSqlServer.cs` | reconhece os erros 2601/2627 (unicidade) e 547 (FK) |
| `Repositorios/RegistroRepository.cs` | implementação de `IRegistroRepository` |
| `Repositorios/ConsultaRegistrosLinq.cs` | tradução de `ConsultaRegistros` (filtros e ordenação) para LINQ |
| `Metadados/MetadadosProvider.cs` | leitura dos metadados com `IMemoryCache` |
| `Repositorios/UsuarioRepository.cs`, `EquipeRepository.cs`, `HistoricoRepository.cs` | usuários, equipes e histórico |
| `Repositorios/ConfiguracaoRepository.cs` | `ConfiguracaoEntidadeEquipe`: se a aprovação está ativa (RN33) |
| `Repositorios/ModeloAvaliacaoRepository.cs`, `AvaliacaoRepository.cs` | modelos e avaliações; médias, distribuição e contagens com `GroupBy`/`Average`/`Count` no banco (RN47, RN48) |
| `Acesso/HasherSenha.cs` | hash de senha com o `PasswordHasher` (PBKDF2), sem o Identity completo (ADR 0016) |
| `Acesso/SituacaoUsuarios.cs` | perfil, equipes ATIVAS e situação de cada usuário, com cache curto (RN23) |
| `ConfiguracaoInfraestrutura.cs` | `AdicionarInfraestrutura()`, chamado só pelo `Program.cs` |

## O EF só mapeia tabelas que já existem

Mudança de schema **sempre** nesta ordem:

1. Script novo `database/scripts/V00x__descricao.sql` (ver [`database/AGENTS.md`](../../../database/AGENTS.md)).
2. Aplique localmente: `cd database/docker && docker compose --env-file ../.env run --rm db-init`.
3. **Só então** atualize a classe de `Tabelas/` (ou do Domain, para dados) e a `...Configuracao.cs`
   da tabela, com os **mesmos** nomes de coluna, tipo (`HasColumnType`), PK, FK (`HasConstraintName`)
   e UNIQUE do script.
4. Rode `dotnet test`. Os testes de integração rodam contra o banco real e pegam mapeamento errado.

Proibido: migrations, `EnsureCreated`, `EnsureDeleted`, `Migrate` ([adr/0003](../../../docs/adr/0003-schema-por-scripts-sql.md)).
As diferenças conscientes entre o script e o mapeamento estão em
[`docs/modelo-de-dados.md`](../../../docs/modelo-de-dados.md#mapeamento-no-ef-core). Mantenha essa lista atualizada.

## Toda consulta é EF Core em LINQ

- **Proibido SQL escrito à mão** na aplicação: `SqlQueryRaw`, `FromSql*`, `ExecuteSql*` e Dapper
  ([ADR 0011](../../../docs/adr/0011-consultas-somente-linq.md)). O teste `SemSqlManualTests` varre `src/` e falha se encontrar.
  `ExecuteDeleteAsync` (LINQ) é permitido.
- Filtros e ordenação usam subconsultas LINQ em `RegistroValor` (campos simples) e `RegistroReferencia`
  (referências), dentro de `ConsultaRegistrosLinq`. Os `CampoId` vêm sempre dos metadados; os valores, de
  `ConsultaRegistros` já tipada pelo Domain. Nunca use texto da URL para montar a consulta.
- Uma consulta por lista, nunca por linha (sem N+1): rótulos em `ObterRotulosAsync`, referências da
  exclusão em `ObterReferenciasQueApontamParaAsync`.

## `RegistroValor` anda junto com `Registro.Dados`

- `RegistroValor` é a cópia tipada dos campos simples ([ADR 0013](../../../docs/adr/0013-registro-valor.md)).
  Ela é **sempre** gravada junto com `Registro.Dados`, no mesmo `SaveChanges`, pelo `SincronizadorRegistro`
  do Domain. Não grave nenhuma das duas sozinha. Na exclusão, o CASCADE do banco apaga os valores.
- Script que altera `Registro.Dados` direto no banco precisa atualizar `RegistroValor` também.
- `RegistroValorTests` (integração) confere a consistência depois de criar, atualizar e excluir.

## Cache da situação dos usuários

- `SituacaoUsuarios` guarda por usuário (perfil, equipes **ativas**, ativo, troca de senha) por
  `Seguranca:CacheUsuarioSegundos` (padrão 60 s). `Invalidar(id)` descarta um usuário; `InvalidarTodos()`
  descarta todos (ex.: equipe desativada), por meio de um sinal de cancelamento compartilhado.
- O cache é por servidor. Com mais de um servidor, uma mudança vale na hora só no servidor que a fez;
  nos outros, em até 60 s.

## Cache de metadados

- O `MetadadosProvider` guarda **o grupo inteiro** (entidades, campos, restrições, dependências) no
  `IMemoryCache` por `MetadadosProvider.TempoCache` (10 min). Grupo inexistente não é guardado.
- O cache é **por servidor**. Metadados alterados direto no banco aparecem em até 10 minutos, ou
  depois de reiniciar a aplicação.
- Quem alterar metadados pela aplicação (funcionalidade futura) **deve** chamar
  `IMetadadosProvider.InvalidarCache(grupoChave)` depois do `SaveChanges`.

## Tradução dos erros do banco

| Erro do SQL Server | `UnidadeDeTrabalho` lança | Quem trata |
|---|---|---|
| 2601 (índice único) ou 2627 (UNIQUE/PK) | `ViolacaoUnicidadeBancoException`. Se a constraint for `UQ_RegistroChaveUnica_Valor`, o `RestricaoUnicaId` vem da mensagem | o caso de uso converte em `ConflitoUnicidadeException` → 409 |
| `DbUpdateConcurrencyException` (`Versao` mudou entre a leitura e o UPDATE, RN12) | `ConflitoConcorrenciaException` | Api → 409 |
| 547 (FK) durante `ExcluirAsync` (alguém criou uma referência no meio da exclusão) | `ConflitoConcorrenciaException`, com rollback | Api → 409 |

Para a concorrência do PUT, `DefinirVersaoEsperada` troca o valor **original** da `Versao` no EF pelo que
o cliente leu: assim o UPDATE sai com `WHERE Versao = @versaoLida`.

O teste `UnidadeDeTrabalhoTests` (integração) confere a tradução com um erro real do SQL Server.

## Regras deste projeto

- Leituras com `AsNoTracking()`. Não crie repositório genérico: só os métodos que os casos de uso usam.
- O escopo de equipes da listagem (`ConsultaRegistros.EquipesPermitidas`/`FiltroEquipe`) é aplicado em
  `ConsultaRegistrosLinq.Filtrar`, no `WHERE`. Não remova nem filtre depois em memória (RN26).
  O mesmo vale para a situação de aprovação (`NaoAprovadosSomenteDoAutor` e `FiltroSituacao`, RN37).
- Ordenação e filtro pela média de avaliação (RN48) são subconsultas correlacionadas em `ConsultaRegistrosLinq`
  (`NotasDoCriterio`). `Average` sobre `tinyint` precisa de conversão para `double` (senão o SQL Server faz média inteira).
- Média e contagem de avaliações: sempre no banco. Nunca traga as avaliações para a memória para calcular.
- `Registro.SituacaoAprovacao` é mapeada **sem** `HasDefaultValue`: o valor padrão do enum é `Pendente`, e o EF
  deixaria de enviá-lo no INSERT (o banco gravaria APROVADO).
- Classes de implementação são `internal sealed`. Só o `DbContext`, as classes de `Tabelas/` e o `ConfiguracaoInfraestrutura` são públicos.
- `Contains` em listas vira `OPENJSON` no EF 8, que exige nível de compatibilidade ≥ 130 (SQL Server 2016+).
  Se o banco de produção tiver nível menor, configure `UseCompatibilityLevel` no `UseSqlServer`.

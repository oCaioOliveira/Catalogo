using Catalogo.Application.Abstracoes;
using Catalogo.Domain.Acesso;
using Catalogo.Infrastructure.Persistencia;
using Microsoft.EntityFrameworkCore;

namespace Catalogo.Infrastructure.Repositorios;

// Todas as consultas são LINQ do EF Core (docs/adr/0011).
internal sealed class EquipeRepository(CatalogoDbContext contexto) : IEquipeRepository
{
    public Task<Equipe?> ObterPorIdAsync(Guid id, CancellationToken cancellationToken) =>
        contexto.Equipes.FirstOrDefaultAsync(e => e.Id == id, cancellationToken);

    public async Task<IReadOnlyList<Equipe>> ObterPorIdsAsync(IReadOnlyCollection<Guid> ids, CancellationToken cancellationToken)
    {
        if (ids.Count == 0)
            return [];

        return await contexto.Equipes.AsNoTracking().Where(e => ids.Contains(e.Id)).ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Equipe>> ListarAsync(bool? ativa, CancellationToken cancellationToken)
    {
        var consulta = contexto.Equipes.AsNoTracking();
        if (ativa is bool valor)
            consulta = consulta.Where(e => e.Ativa == valor);

        return await consulta.OrderBy(e => e.Nome).ToListAsync(cancellationToken);
    }

    // A comparação segue a collation do banco (CI_AI), a mesma do UNIQUE do nome.
    public Task<bool> ExisteNomeAsync(string nome, Guid? ignorarEquipeId, CancellationToken cancellationToken) =>
        contexto.Equipes.AnyAsync(e => e.Nome == nome && (ignorarEquipeId == null || e.Id != ignorarEquipeId), cancellationToken);

    public Task<int> ContarUsuariosQueFicariamSemEquipeAsync(Guid equipeId, CancellationToken cancellationToken) =>
        contexto.Usuarios.CountAsync(
            u => u.Ativo
                 && u.Perfil != Perfil.Administrador
                 && u.Equipes.Any(v => v.EquipeId == equipeId)
                 && !u.Equipes.Any(v => v.EquipeId != equipeId && contexto.Equipes.Any(e => e.Id == v.EquipeId && e.Ativa)),
            cancellationToken);

    public void Adicionar(Equipe equipe) => contexto.Equipes.Add(equipe);
}

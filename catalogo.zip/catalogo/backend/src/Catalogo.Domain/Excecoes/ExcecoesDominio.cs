namespace Catalogo.Domain.Excecoes;

// Exceções de domínio. A Api converte cada uma num status HTTP
// (tabela em src/Catalogo.Api/AGENTS.md). Não use Exception genérica para regra de negócio.

/// <summary>Base das exceções de domínio.</summary>
public abstract class ExcecaoDominio(string mensagem, Exception? excecaoOriginal = null)
    : Exception(mensagem, excecaoOriginal);

/// <summary>
/// Os dados enviados violam regras de validação. Carrega TODOS os erros, por campo (RN05).
/// Vira HTTP 400 (ValidationProblemDetails).
/// </summary>
public sealed class ValidacaoRegistroException : ExcecaoDominio
{
    public ValidacaoRegistroException(IReadOnlyDictionary<string, string[]> erros)
        : base("Um ou mais campos são inválidos.")
    {
        Erros = erros;
    }

    /// <summary>Chave do campo → mensagens de erro desse campo.</summary>
    public IReadOnlyDictionary<string, string[]> Erros { get; }
}

/// <summary>Grupo, entidade ou registro não existe. Vira HTTP 404.</summary>
public sealed class RecursoNaoEncontradoException(string mensagem) : ExcecaoDominio(mensagem);

/// <summary>
/// Já existe registro com os mesmos valores numa restrição única (RN09). Vira HTTP 409.
/// </summary>
public sealed class ConflitoUnicidadeException : ExcecaoDominio
{
    public ConflitoUnicidadeException(string nomeRestricao, IReadOnlyList<string> campos, string mensagem)
        : base(mensagem)
    {
        NomeRestricao = nomeRestricao;
        Campos = campos;
    }

    /// <summary>Nome da restrição violada (ex.: "uq_comunidade_nome").</summary>
    public string NomeRestricao { get; }

    /// <summary>Chaves dos campos que formam a restrição.</summary>
    public IReadOnlyList<string> Campos { get; }
}

/// <summary>
/// O registro foi alterado por outra pessoa depois de ser lido (Versao diferente, RN12). Vira HTTP 409.
/// </summary>
public sealed class ConflitoConcorrenciaException(string mensagem, Exception? excecaoOriginal = null)
    : ExcecaoDominio(mensagem, excecaoOriginal);

/// <summary>
/// Sem identificação válida: credenciais erradas no login, token ausente/inválido, ou usuário
/// desativado depois de logar. Vira HTTP 401. A mensagem do login é sempre genérica (RN23).
/// </summary>
public sealed class NaoAutenticadoException(string mensagem) : ExcecaoDominio(mensagem);

/// <summary>
/// O usuário está identificado mas não pode fazer a operação (RN26). Vira HTTP 403.
/// <see cref="Codigo"/> identifica casos que o front trata de forma especial (ex.: troca de senha obrigatória).
/// </summary>
public sealed class AcessoNegadoException(string mensagem, string? codigo = null) : ExcecaoDominio(mensagem)
{
    /// <summary>Código estável para o front (ex.: "TROCA_DE_SENHA_OBRIGATORIA"). Nulo no caso comum.</summary>
    public string? Codigo { get; } = codigo;
}

/// <summary>
/// A operação violaria uma regra de negócio que não é de validação de campo, como desativar o
/// último administrador (RN30) ou deixar usuários sem equipe ativa (RN31). Vira HTTP 409.
/// </summary>
public sealed class RegraDeNegocioException(
    string mensagem, string? codigo = null, IReadOnlyDictionary<string, object?>? dados = null) : ExcecaoDominio(mensagem)
{
    /// <summary>Código estável para o front (ex.: "ULTIMO_ADMINISTRADOR").</summary>
    public string? Codigo { get; } = codigo;

    /// <summary>Dados extras para o front (ex.: { "quantidade": 3 }). Viram campos do ProblemDetails.</summary>
    public IReadOnlyDictionary<string, object?> Dados { get; } = dados ?? new Dictionary<string, object?>();
}

namespace Catalogo.Domain.Metadados;

/// <summary>
/// Agrupa as entidades de uma mesma listagem (tabela dbo.Grupo), ex.: "testes_desempenho".
/// </summary>
public sealed class Grupo
{
    public required Guid Id { get; init; }

    /// <summary>Identificador usado na URL (ex.: "testes_desempenho").</summary>
    public required string Chave { get; init; }

    public required string Nome { get; init; }
    public string? Descricao { get; init; }
    public required IReadOnlyList<Entidade> Entidades { get; init; }

    /// <summary>
    /// Procura uma entidade pela chave da URL, sem diferenciar maiúsculas
    /// (igual à collation CI do banco, onde UQ_Entidade_Grupo_Chave também não diferencia).
    /// </summary>
    public Entidade? ObterEntidade(string chave) =>
        Entidades.FirstOrDefault(e => string.Equals(e.Chave, chave, StringComparison.OrdinalIgnoreCase));

    public Entidade? ObterEntidade(Guid entidadeId) => Entidades.FirstOrDefault(e => e.Id == entidadeId);
}

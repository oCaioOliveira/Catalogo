namespace Catalogo.Domain.Metadados;

/// <summary>
/// Um "tipo de item" cadastrável (tabela dbo.Entidade), ex.: comunidade, projeto, cenario_teste.
/// Modelo de leitura imutável (ver <see cref="Campo"/>).
/// </summary>
public sealed class Entidade
{
    public required Guid Id { get; init; }
    public required Guid GrupoId { get; init; }

    /// <summary>Identificador usado na URL (ex.: "cenario_teste").</summary>
    public required string Chave { get; init; }

    public required string Nome { get; init; }
    public string? Descricao { get; init; }

    /// <summary>
    /// Verdadeiro (padrão): cada registro pertence a uma equipe. Falso: registros GLOBAIS, vistos por
    /// todos e alterados só pelo administrador (RN27, docs/adr/0017).
    /// </summary>
    public bool EscopoEquipe { get; init; } = true;

    public bool EhGlobal => !EscopoEquipe;

    /// <summary>Campo usado como rótulo do registro em selects e listas.</summary>
    public Guid? CampoExibicaoId { get; init; }

    /// <summary>Todos os campos, ativos e inativos, ordenados por <see cref="Campo.Ordem"/>.</summary>
    public required IReadOnlyList<Campo> Campos { get; init; }

    public IReadOnlyList<RestricaoUnica> RestricoesUnicas { get; init; } = [];

    /// <summary>Dependências dos campos desta entidade (Dependencia.Campo é sempre desta entidade).</summary>
    public IReadOnlyList<CampoDependencia> Dependencias { get; init; } = [];

    /// <summary>
    /// Procura um campo pela chave. A comparação é exata (diferencia maiúsculas):
    /// a chave enviada no JSON tem que ser igual à cadastrada.
    /// </summary>
    public Campo? ObterCampo(string chave) =>
        Campos.FirstOrDefault(c => string.Equals(c.Chave, chave, StringComparison.Ordinal));

    public Campo? ObterCampo(Guid campoId) => Campos.FirstOrDefault(c => c.Id == campoId);
}

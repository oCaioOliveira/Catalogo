using Catalogo.Domain.ChavesUnicas;
using Catalogo.Domain.Metadados;
using Catalogo.Domain.Validacao;

namespace Catalogo.Domain.Registros;

/// <summary>
/// Copia um <see cref="RegistroValidado"/> para um <see cref="Registro"/>, deixando Dados,
/// Referencias, Valores e ChavesUnicas coerentes entre si. É o MESMO código para criar
/// (registro novo, listas vazias) e para atualizar (registro carregado do banco):
///   - o que não existe mais é removido da lista;
///   - o que mudou é alterado no próprio objeto;
///   - o que é novo é adicionado.
/// Assim Registro.Dados e RegistroValor nunca ficam fora de sincronia (docs/adr/0013).
/// </summary>
public static class SincronizadorRegistro
{
    public static void Aplicar(
        Registro registro,
        Entidade entidade,
        RegistroValidado validado,
        IReadOnlyList<ChaveUnicaCalculada> chavesUnicas)
    {
        // A entidade de um registro nunca muda (faz parte das FKs compostas).
        if (registro.EntidadeId == Guid.Empty)
            registro.EntidadeId = entidade.Id;
        else if (registro.EntidadeId != entidade.Id)
            throw new InvalidOperationException("O registro é de outra entidade.");

        registro.Dados = validado.SerializarDadosSimples();
        SincronizarReferencias(registro, entidade, validado);
        SincronizarValores(registro, entidade, validado);
        SincronizarChavesUnicas(registro, entidade, chavesUnicas);
    }

    private static void SincronizarReferencias(Registro registro, Entidade entidade, RegistroValidado validado)
    {
        var desejadas = validado.Referencias.ToDictionary(r => r.Campo.Id);

        // Campo REFERENCIA que ficou vazio (RN15: ausente no PUT = removido).
        registro.Referencias.RemoveAll(r => !desejadas.ContainsKey(r.CampoId));

        foreach (var desejada in desejadas.Values)
        {
            var existente = registro.Referencias.FirstOrDefault(r => r.CampoId == desejada.Campo.Id);
            if (existente is null)
            {
                registro.Referencias.Add(new RegistroReferencia
                {
                    RegistroOrigemId = registro.Id,
                    EntidadeOrigemId = entidade.Id,
                    CampoId = desejada.Campo.Id,
                    RegistroDestinoId = desejada.RegistroDestinoId,
                    EntidadeDestinoId = desejada.Campo.EntidadeReferenciadaId!.Value,
                });
            }
            else if (existente.RegistroDestinoId != desejada.RegistroDestinoId)
            {
                existente.RegistroDestinoId = desejada.RegistroDestinoId;
            }
        }
    }

    private static void SincronizarValores(Registro registro, Entidade entidade, RegistroValidado validado)
    {
        var desejados = new Dictionary<Guid, RegistroValor>();
        foreach (var (chave, valor) in validado.DadosSimples)
        {
            var campo = entidade.ObterCampo(chave);
            if (campo is null || valor is null)
                continue;

            var registroValor = ConversorValorTipado.ParaValor(campo, valor);
            if (registroValor is not null)
                desejados[campo.Id] = registroValor;
        }

        registro.Valores.RemoveAll(v => !desejados.ContainsKey(v.CampoId));

        foreach (var desejado in desejados.Values)
        {
            var existente = registro.Valores.FirstOrDefault(v => v.CampoId == desejado.CampoId);
            if (existente is null)
            {
                desejado.RegistroId = registro.Id;
                registro.Valores.Add(desejado);
            }
            else
            {
                existente.ValorTexto = desejado.ValorTexto;
                existente.ValorNumero = desejado.ValorNumero;
                existente.ValorData = desejado.ValorData;
                existente.ValorBooleano = desejado.ValorBooleano;
            }
        }
    }

    private static void SincronizarChavesUnicas(Registro registro, Entidade entidade, IReadOnlyList<ChaveUnicaCalculada> chavesUnicas)
    {
        var desejadas = chavesUnicas.ToDictionary(c => c.Restricao.Id);

        // Restrição que ficou com algum valor vazio deixa de ter chave (RN10).
        registro.ChavesUnicas.RemoveAll(c => !desejadas.ContainsKey(c.RestricaoUnicaId));

        foreach (var desejada in desejadas.Values)
        {
            var existente = registro.ChavesUnicas.FirstOrDefault(c => c.RestricaoUnicaId == desejada.Restricao.Id);
            if (existente is null)
            {
                registro.ChavesUnicas.Add(new RegistroChaveUnica
                {
                    RestricaoUnicaId = desejada.Restricao.Id,
                    EntidadeId = entidade.Id,
                    RegistroId = registro.Id,
                    ValorHash = desejada.ValorHash,
                });
            }
            else if (!existente.ValorHash.AsSpan().SequenceEqual(desejada.ValorHash))
            {
                existente.ValorHash = desejada.ValorHash;
            }
        }
    }
}

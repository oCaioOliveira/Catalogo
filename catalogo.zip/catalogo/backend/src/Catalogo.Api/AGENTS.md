# AGENTS.md — Catalogo.Api

Complementa o [`AGENTS.md` da raiz](../../AGENTS.md). O caminho de uma requisição até o banco e o
papel do tratador de erros estão em [`docs/arquitetura.md`](../../../docs/arquitetura.md#tratamento-de-erros).
As mensagens de erro de validação seguem [`docs/regras-de-negocio.md`](../../../docs/regras-de-negocio.md#rn05--todos-os-erros-de-uma-vez).

## Convenção de rotas

Tudo fica sob `/api/grupos/{grupo}/entidades`. `{grupo}` e `{entidade}` são as **chaves** dos
metadados (ex.: `testes_desempenho`, `cenario_teste`) e não diferenciam maiúsculas.

| Método | Rota | Controller | Sucesso |
|---|---|---|---|
| GET | `/api/grupos/{grupo}/entidades` | `EntidadesController.Listar` (`?equipeId=` devolve `requerAprovacao`) | 200 |
| GET | `/api/grupos/{grupo}/entidades/{entidade}/registros` | `RegistrosController.Listar` | 200 (página, RN17) |
| POST | `/api/grupos/{grupo}/entidades/{entidade}/registros` | `RegistrosController.Criar` | 201 + header `Location` |
| GET | `/api/grupos/{grupo}/entidades/{entidade}/registros/{id:guid}` | `RegistrosController.Obter` | 200 |
| PUT | `/api/grupos/{grupo}/entidades/{entidade}/registros/{id:guid}` | `RegistrosController.Atualizar` | 200 (RN15) |
| DELETE | `/api/grupos/{grupo}/entidades/{entidade}/registros/{id:guid}` | `RegistrosController.Excluir` | 204 (RN16) |
| GET | `/api/grupos/{grupo}/entidades/{entidade}/campos/{campo}/opcoes` | `CamposController.Opcoes` | 200 (RN21) |
| GET | `.../registros/{id:guid}/historico` | `RegistrosController.Historico` | 200 (RN32) |
| POST | `.../registros/{id:guid}/aprovacao` | `RegistrosController.Decidir` (`{ decisao, justificativa }`) | 200 com o registro (RN36) |
| GET, PUT | `/api/equipes/{equipeId:guid}/configuracoes/grupos/{grupo}/entidades/{entidade}/aprovacao` | `ConfiguracoesController` (`{ ativa }`) | 200 (RN33) |
| GET | `.../aprovacao/historico` (mesma rota acima) | `ConfiguracoesController.Historico` | 200 (RN32, RN33) |
| GET, POST, PUT | `/api/equipes/{equipeId:guid}/configuracoes/grupos/{grupo}/entidades/{entidade}/avaliacao` | `ModelosAvaliacaoController` (modelo ativo; POST 201, 409 se já há ativo) | 200/201 (RN40 a RN43) |
| GET, PATCH `.../ativacao`, GET `.../historico` | `.../avaliacao/modelos`, `.../avaliacao/ativacao`, `.../avaliacao/historico` | `ModelosAvaliacaoController` | 200 |
| GET, PUT `minha`, DELETE `minha`, GET `historico` | `.../registros/{id:guid}/avaliacoes` | `AvaliacoesController` (PUT: 201 ao criar, 200 ao editar) | RN44 a RN47 |
| GET | `/api/aprovacoes/pendentes` | `AprovacoesController.Pendentes` (filtros `grupo`, `entidade`, `equipeId`) | 200 (página, RN36) |
| POST | `/api/auth/login` | `AuthController.Login` (anônimo, com rate limiting) | 200 + token |
| POST | `/api/auth/trocar-senha` | `AuthController.TrocarSenha` | 204 |
| GET | `/api/auth/eu` | `AuthController.Eu` | 200 |
| GET, POST, PUT, PATCH `.../ativacao`, GET `.../historico` | `/api/equipes` | `EquipesController` (só ADMINISTRADOR) | |
| GET, POST, PUT, PATCH `.../ativacao`, POST `.../redefinir-senha`, GET `.../historico` | `/api/usuarios` | `UsuariosController` (só ADMINISTRADOR) | |
| GET | `/health` | health check (inclui o banco, anônimo) | 200 `Healthy` |

Rotas novas: substantivos no plural, em português, minúsculas (ex.: `/registros/{id}/historico`).

## Todo endpoint exige autenticação

- Há uma **política de fallback**: todo endpoint exige um usuário autenticado. Exceções documentadas:
  `POST /api/auth/login` (`[AllowAnonymous]`) e `/health`. Endpoint novo anônimo precisa de justificativa no PR
  e de uma linha nesta seção.
- Endpoints que funcionam com a troca de senha pendente levam `[PermitirSenhaProvisoria]` (hoje só
  `trocar-senha` e `eu`). Os demais respondem 403 `TROCA_DE_SENHA_OBRIGATORIA` (RN25).
- O controller **não** decide permissão: o caso de uso consulta a `PoliticaPermissao`. Nada de
  `[Authorize(Roles = ...)]` nem `User.IsInRole` aqui.
- Nunca registre senha, token ou hash no log. Use a matrícula para identificar quem fez.
- Configuração e funcionamento: [`docs/seguranca.md`](../../../docs/seguranca.md).

## Controllers finos

- Use `Controller`s com `[ApiController]` (sem Minimal APIs), dentro de `Controllers/`, com nome
  terminado em `Controller`. Garantido por `Controllers_FicamNaPastaControllersETerminamComController`.
- Cada ação só chama **um** caso de uso e devolve o resultado. Nada de regra de negócio aqui.
- **Sem `try/catch`**: as exceções sobem para o `Erros/TratadorExcecoesGlobal.cs`.
- Declare os status possíveis com `[ProducesResponseType]`: é isso que aparece no Swagger.
- Só o `Program.cs` pode usar a Infrastructure (`Api_SoOProgramUsaAInfrastructure`).
- **Parâmetros de URL dinâmicos** (filtros da listagem, que dependem dos campos da entidade): leia com
  `ParametrosDaUrl.Ler(Request)` e passe ao caso de uso. Quem interpreta é o Domain (`InterpretadorConsulta`).
  Os parâmetros fixos (`pagina`, `tamanho`...) são declarados como `string?` na ação só para aparecerem no Swagger.

## Exceção → status HTTP

Feito **só** no `TratadorExcecoesGlobal` (um `IExceptionHandler`). Toda resposta de erro é ProblemDetails, com `traceId`.

| Exceção | Status | Corpo |
|---|---|---|
| `ValidacaoRegistroException` | 400 | `ValidationProblemDetails` com `errors` por campo (ou por parâmetro de URL) |
| JSON inválido ou corpo que não é objeto | 400 | automático do `[ApiController]` |
| `RecursoNaoEncontradoException` | 404 | `detail` com o que não foi encontrado |
| `ConflitoUnicidadeException` | 409 | extensões `restricao` e `campos` |
| `ConflitoConcorrenciaException` | 409 | `detail` |
| `ExclusaoBloqueadaException` | 409 | extensão `dependencias`: `[{ entidade, campo, quantidade, exemplos }]` |
| `RegraDeNegocioException` | 409 | extensão `codigo` (ex.: `ULTIMO_ADMINISTRADOR`, `REGISTRO_NAO_PENDENTE`, `MODELO_ATIVO_EXISTENTE`, `REGISTRO_NAO_APROVADO`) e os `Dados` da exceção como extensões extras (ex.: `APROVACOES_PENDENTES` traz `quantidade`) |
| `NaoAutenticadoException` (e token ausente/inválido) | 401 | `detail` |
| `AcessoNegadoException` | 403 | extensão `codigo` quando houver |
| rate limiting do login | 429 | `detail` |
| qualquer outra | 500 | mensagem genérica. `detail` e `excecao` (stack trace) **só em Development** |

Exceção de domínio nova? Adicione o `case` no tratador **e** a linha nesta tabela.

## Ambientes e configuração

| Ambiente (`ASPNETCORE_ENVIRONMENT`) | Arquivo | Particularidades |
|---|---|---|
| `Development` | `appsettings.Development.json` | Swagger UI em `/swagger`, SQL do EF no log, connection string do **user-secrets** |
| `Homologacao` | `appsettings.Homologacao.json` | log em JSON no console |
| `Production` | `appsettings.Production.json` | log em JSON no console |
| `Testes` | (nenhum) | usado só pelos testes de integração |

- Chave do JWT: `Jwt:ChaveAssinatura` (user-secrets em dev; `Jwt__ChaveAssinatura` nos servidores). Sem ela, a API não sobe.
- Comando `criar-admin` (primeiro administrador): `Configuracao/ComandoCriarAdmin.cs`, chamado no início do `Program.cs`.
- Connection string: chave `ConnectionStrings:Catalogo`. Em desenvolvimento vem do user-secrets
  (ver [README](../../README.md)). Nos servidores vem da variável de ambiente
  `ConnectionStrings__Catalogo`. **Nunca** em arquivo versionado. Sem ela, a API não sobe e mostra mensagem clara.
- Logging: o logger padrão (`ILogger<T>`) com **message templates** (`"Registro {RegistroId} criado"`,
  nunca interpolação `$"..."`), para os campos virarem propriedades no log JSON.
- Ficam desligadas no `appsettings.json` duas categorias de log que repetiam como erro o que o tratador
  já registra: `Microsoft.AspNetCore.Diagnostics.ExceptionHandlerMiddleware` e `Microsoft.EntityFrameworkCore.Update`.
  Os 500 continuam registrados como erro, com a exceção completa, pelo `TratadorExcecoesGlobal`.

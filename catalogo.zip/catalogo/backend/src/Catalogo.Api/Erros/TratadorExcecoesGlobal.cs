using Catalogo.Domain.Excecoes;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace Catalogo.Api.Erros;

/// <summary>
/// Único lugar que converte exceções em respostas HTTP (ProblemDetails, RFC 9457).
/// Por isso os controllers NÃO têm try/catch. Tabela exceção → status em src/Catalogo.Api/AGENTS.md.
/// </summary>
internal sealed class TratadorExcecoesGlobal(
    IProblemDetailsService problemDetailsService,
    IHostEnvironment ambiente,
    ILogger<TratadorExcecoesGlobal> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        var problema = CriarProblema(exception);

        if (problema.Status == StatusCodes.Status500InternalServerError)
        {
            logger.LogError(exception, "Erro inesperado em {Metodo} {Caminho}",
                httpContext.Request.Method, httpContext.Request.Path);
        }
        else
        {
            // Erros de negócio são esperados: registra sem stack trace.
            logger.LogInformation("Requisição {Metodo} {Caminho} recusada com {Status}: {Mensagem}",
                httpContext.Request.Method, httpContext.Request.Path, problema.Status, exception.Message);
        }

        httpContext.Response.StatusCode = problema.Status!.Value;
        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            ProblemDetails = problema,
            Exception = exception,
        });
    }

    private ProblemDetails CriarProblema(Exception exception)
    {
        switch (exception)
        {
            case ValidacaoRegistroException validacao:
                // 400 com os erros por campo: { "errors": { "codigo_sigla": ["..."], ... } }
                return new ValidationProblemDetails(validacao.Erros.ToDictionary(e => e.Key, e => e.Value))
                {
                    Status = StatusCodes.Status400BadRequest,
                    Title = "Um ou mais campos são inválidos.",
                };

            case NaoAutenticadoException:
                return new ProblemDetails
                {
                    Status = StatusCodes.Status401Unauthorized,
                    Title = "Não autenticado.",
                    Detail = exception.Message,
                };

            case AcessoNegadoException acessoNegado:
                var problemaAcesso = new ProblemDetails
                {
                    Status = StatusCodes.Status403Forbidden,
                    Title = "Acesso negado.",
                    Detail = acessoNegado.Message,
                };
                if (acessoNegado.Codigo is not null)
                    problemaAcesso.Extensions["codigo"] = acessoNegado.Codigo;
                return problemaAcesso;

            case RegraDeNegocioException regra:
                var problemaRegra = new ProblemDetails
                {
                    Status = StatusCodes.Status409Conflict,
                    Title = "Operação não permitida.",
                    Detail = regra.Message,
                };
                if (regra.Codigo is not null)
                    problemaRegra.Extensions["codigo"] = regra.Codigo;
                foreach (var (chave, valor) in regra.Dados)
                    problemaRegra.Extensions[chave] = valor;
                return problemaRegra;

            case RecursoNaoEncontradoException:
                return new ProblemDetails
                {
                    Status = StatusCodes.Status404NotFound,
                    Title = "Recurso não encontrado.",
                    Detail = exception.Message,
                };

            case ConflitoUnicidadeException conflito:
                var problemaUnicidade = new ProblemDetails
                {
                    Status = StatusCodes.Status409Conflict,
                    Title = "Registro duplicado.",
                    Detail = conflito.Message,
                };
                problemaUnicidade.Extensions["restricao"] = conflito.NomeRestricao;
                problemaUnicidade.Extensions["campos"] = conflito.Campos;
                return problemaUnicidade;

            case ExclusaoBloqueadaException bloqueio:
                // 409 com o que impede a exclusão: [{ entidade, campo, quantidade, exemplos }] (RN16).
                var problemaExclusao = new ProblemDetails
                {
                    Status = StatusCodes.Status409Conflict,
                    Title = "Exclusão bloqueada.",
                    Detail = bloqueio.Message + " " + string.Join("; ", bloqueio.Dependencias.Select(d =>
                        $"{d.Quantidade} registro(s) de '{d.Entidade}' pelo campo '{d.Campo}'")) + ".",
                };
                problemaExclusao.Extensions["dependencias"] = bloqueio.Dependencias;
                return problemaExclusao;

            case ConflitoConcorrenciaException:
                return new ProblemDetails
                {
                    Status = StatusCodes.Status409Conflict,
                    Title = "Conflito de concorrência.",
                    Detail = exception.Message,
                };

            default:
                var problemaInterno = new ProblemDetails
                {
                    Status = StatusCodes.Status500InternalServerError,
                    Title = "Erro interno.",
                    Detail = "Ocorreu um erro inesperado. Informe o traceId ao suporte.",
                };
                // Detalhes técnicos SÓ em Development: fora dele podem expor informação interna.
                if (ambiente.IsDevelopment())
                {
                    problemaInterno.Detail = exception.Message;
                    problemaInterno.Extensions["excecao"] = exception.ToString();
                }
                return problemaInterno;
        }
    }
}

using Catalogo.Application.Abstracoes;
using Catalogo.Application.CasosDeUso;
using Catalogo.Application.CasosDeUso.Acesso;
using Catalogo.Application.CasosDeUso.Administracao;
using Catalogo.Application.CasosDeUso.Aprovacao;
using Catalogo.Application.CasosDeUso.Avaliacoes;
using Catalogo.Application.CasosDeUso.Historico;
using Catalogo.Application.Comum;
using Catalogo.Domain.ChavesUnicas;
using Catalogo.Domain.Validacao;

namespace Catalogo.Api.Configuracao;

/// <summary>Registro do Domain e da Application na injeção de dependência.</summary>
public static class ConfiguracaoAplicacao
{
    public static IServiceCollection AdicionarAplicacao(this IServiceCollection services)
    {
        // Domain: sem estado, uma instância para a aplicação toda.
        services.AddSingleton(new ValidadorRegistro(ValidadoresPadrao.Todos()));
        services.AddSingleton<CalculadoraChaveUnica>();
        // Relógio do sistema (nos testes pode ser trocado por um relógio fixo).
        services.AddSingleton(TimeProvider.System);

        // Peças compartilhadas pelos casos de uso.
        services.AddScoped<PreparadorRegistro>();
        services.AddScoped<MontadorRegistroDto>();
        services.AddScoped<ResolvedorEquipe>();
        services.AddScoped<ServicoHistorico>();
        services.AddScoped<MontadorHistorico>();
        services.AddScoped<ContextoAprovacao>();
        services.AddScoped<MontadorModeloAvaliacao>();

        // Fornecedor de identidade: matrícula e senha locais. Para um SSO, troque só esta linha (docs/adr/0015).
        services.AddScoped<IProvedorIdentidade, ProvedorIdentidadeLocal>();

        // Casos de uso: injetados direto nos controllers (sem mediator, ver docs/adr/0004).
        services.AddScoped<ListarEntidades>();
        services.AddScoped<ListarRegistros>();
        services.AddScoped<CriarRegistro>();
        services.AddScoped<ObterRegistro>();
        services.AddScoped<AtualizarRegistro>();
        services.AddScoped<ExcluirRegistro>();
        services.AddScoped<ListarOpcoes>();

        services.AddScoped<Login>();
        services.AddScoped<TrocarSenha>();
        services.AddScoped<ObterUsuarioLogado>();
        services.AddScoped<CriarPrimeiroAdministrador>();

        services.AddScoped<ListarEquipes>();
        services.AddScoped<ObterEquipe>();
        services.AddScoped<CriarEquipe>();
        services.AddScoped<AtualizarEquipe>();
        services.AddScoped<AlterarAtivacaoEquipe>();
        services.AddScoped<ListarUsuarios>();
        services.AddScoped<ObterUsuario>();
        services.AddScoped<CriarUsuario>();
        services.AddScoped<AtualizarUsuario>();
        services.AddScoped<AlterarAtivacaoUsuario>();
        services.AddScoped<RedefinirSenhaUsuario>();

        services.AddScoped<ListarHistoricoRegistro>();
        services.AddScoped<ListarHistoricoAcesso>();

        services.AddScoped<ObterConfiguracaoAprovacao>();
        services.AddScoped<DefinirConfiguracaoAprovacao>();
        services.AddScoped<ListarHistoricoConfiguracao>();
        services.AddScoped<DecidirAprovacao>();
        services.AddScoped<ListarPendentes>();

        services.AddScoped<ObterModeloAvaliacao>();
        services.AddScoped<ListarModelosAvaliacao>();
        services.AddScoped<CriarModeloAvaliacao>();
        services.AddScoped<AtualizarModeloAvaliacao>();
        services.AddScoped<AlterarAtivacaoModeloAvaliacao>();
        services.AddScoped<ListarHistoricoModeloAvaliacao>();
        services.AddScoped<AvaliarRegistro>();
        services.AddScoped<RemoverMinhaAvaliacao>();
        services.AddScoped<ListarAvaliacoesRegistro>();
        services.AddScoped<ListarHistoricoAvaliacoes>();

        return services;
    }
}

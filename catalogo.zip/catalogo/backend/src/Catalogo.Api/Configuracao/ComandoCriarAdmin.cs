using Catalogo.Application.CasosDeUso.Acesso;
using Catalogo.Domain.Excecoes;

namespace Catalogo.Api.Configuracao;

/// <summary>
/// Comando de linha para criar o PRIMEIRO administrador:
/// <code>CATALOGO_ADMIN_SENHA='...' dotnet run --project src/Catalogo.Api -- criar-admin --matricula admin --nome "Fulano"</code>
/// A senha vem da variável de ambiente (nunca de argumento, que fica no histórico do terminal) e
/// precisa ser trocada no primeiro acesso. Só funciona se não houver administrador ativo (RN30).
/// </summary>
public static class ComandoCriarAdmin
{
    public const string Nome = "criar-admin";
    public const string VariavelSenha = "CATALOGO_ADMIN_SENHA";

    public static bool EhEsteComando(string[] args) => args.Length > 0 && args[0] == Nome;

    /// <returns>Código de saída do processo: 0 = sucesso.</returns>
    public static async Task<int> ExecutarAsync(IServiceProvider servicos, string[] args, string? senha, TextWriter saida)
    {
        var matricula = LerOpcao(args, "--matricula");
        var nome = LerOpcao(args, "--nome");
        if (string.IsNullOrEmpty(senha))
        {
            await saida.WriteLineAsync($"Erro: defina a senha na variável de ambiente {VariavelSenha}.");
            return 1;
        }

        using var escopo = servicos.CreateScope();
        var casoDeUso = escopo.ServiceProvider.GetRequiredService<CriarPrimeiroAdministrador>();

        try
        {
            var criado = await casoDeUso.ExecutarAsync(matricula, nome, senha, CancellationToken.None);
            await saida.WriteLineAsync(
                $"Administrador '{criado.Matricula}' criado (id {criado.Id}). Troque a senha no primeiro acesso.");
            return 0;
        }
        catch (ValidacaoRegistroException ex)
        {
            await saida.WriteLineAsync("Erro: " + string.Join("; ", ex.Erros.Select(e => $"{e.Key}: {string.Join(" ", e.Value)}")));
            return 1;
        }
        catch (ExcecaoDominio ex)
        {
            await saida.WriteLineAsync("Erro: " + ex.Message);
            return 1;
        }
    }

    private static string? LerOpcao(string[] args, string nome)
    {
        var indice = Array.IndexOf(args, nome);
        return indice >= 0 && indice + 1 < args.Length ? args[indice + 1] : null;
    }
}

using System.Text.Json.Nodes;
using Microsoft.OpenApi;

namespace Catalogo.Api.Configuracao;

/// <summary>
/// Geração do documento OpenAPI com Swashbuckle (no .NET 8 a geração nativa ainda não existe).
/// O Swagger UI só é publicado em Development (ver Program.cs).
/// </summary>
public static class ConfiguracaoSwagger
{
    public static IServiceCollection AdicionarSwagger(this IServiceCollection services)
    {
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(opcoes =>
        {
            opcoes.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "Catalogo API",
                Version = "v1",
                Description = "Cadastro genérico guiado por metadados. Regras em docs/regras-de-negocio.md.",
            });

            // Os dados de um registro são um objeto JSON livre: as chaves são os campos da entidade
            // (consulte GET /api/grupos/{grupo}/entidades para saber quais são).
            opcoes.MapType<JsonObject>(() => new OpenApiSchema
            {
                Type = JsonSchemaType.Object,
                AdditionalPropertiesAllowed = true,
            });

            // Botão "Authorize" do Swagger UI: cole o token devolvido por POST /api/auth/login.
            opcoes.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Type = SecuritySchemeType.Http,
                Scheme = "bearer",
                BearerFormat = "JWT",
                Description = "Token devolvido por POST /api/auth/login.",
            });
            opcoes.AddSecurityRequirement(documento => new OpenApiSecurityRequirement
            {
                [new OpenApiSecuritySchemeReference("Bearer", documento)] = [],
            });
        });

        return services;
    }
}

using System.Text.Json.Nodes;
using Catalogo.Application.CasosDeUso;
using Catalogo.Application.CasosDeUso.Aprovacao;
using Catalogo.Application.CasosDeUso.Historico;
using Catalogo.Application.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Catalogo.Api.Controllers;

/// <summary>
/// Registros de uma entidade. Controller fino: cada ação só chama um caso de uso.
/// Erros viram ProblemDetails no TratadorExcecoesGlobal (sem try/catch aqui).
/// </summary>
[ApiController]
[Route("api/grupos/{grupo}/entidades/{entidade}/registros")]
[Produces("application/json")]
public sealed class RegistrosController(
    ListarRegistros listarRegistros,
    CriarRegistro criarRegistro,
    ObterRegistro obterRegistro,
    AtualizarRegistro atualizarRegistro,
    ExcluirRegistro excluirRegistro,
    ListarHistoricoRegistro listarHistorico,
    DecidirAprovacao decidirAprovacao,
    ILogger<RegistrosController> logger) : ControllerBase
{
    /// <summary>
    /// Lista os registros, paginados (RN17), com filtros (RN18) e ordenação (RN19).
    /// Filtros: chave=valor, chave.contem=valor, chave.de=valor, chave.ate=valor.
    /// </summary>
    /// <param name="grupo">Chave do grupo.</param>
    /// <param name="entidade">Chave da entidade.</param>
    /// <param name="pagina">Página, a partir de 1 (padrão 1).</param>
    /// <param name="tamanho">Itens por página (padrão 20, máximo 100).</param>
    /// <param name="ordenacao">Chave do campo, criadoEm ou atualizadoEm; "-" na frente = decrescente (padrão -criadoEm).</param>
    /// <param name="cancellationToken">Cancelamento da requisição.</param>
    [HttpGet]
    [ProducesResponseType<PaginaDto<RegistroDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<PaginaDto<RegistroDto>>> Listar(
        string grupo, string entidade,
        // Declarados só para aparecerem no Swagger: a leitura de todos os parâmetros (inclusive os
        // filtros, que dependem da entidade) é feita por ParametrosDaUrl.
        [FromQuery] string? pagina, [FromQuery] string? tamanho, [FromQuery] string? ordenacao,
        CancellationToken cancellationToken)
    {
        return Ok(await listarRegistros.ExecutarAsync(grupo, entidade, ParametrosDaUrl.Ler(Request), cancellationToken));
    }

    /// <summary>
    /// Cria um registro. O corpo é um objeto plano com os campos da entidade
    /// (referências como o id do registro apontado).
    /// </summary>
    [HttpPost]
    [Consumes("application/json")]
    [ProducesResponseType<RegistroDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<RegistroDto>> Criar(
        string grupo, string entidade, [FromBody] JsonObject dados, CancellationToken cancellationToken)
    {
        var registro = await criarRegistro.ExecutarAsync(grupo, entidade, dados, cancellationToken);

        logger.LogInformation("Registro {RegistroId} criado em {Grupo}/{Entidade}", registro.Id, grupo, entidade);

        // 201 com o header Location apontando para o GET abaixo.
        return CreatedAtAction(nameof(Obter), new { grupo, entidade, id = registro.Id }, registro);
    }

    /// <summary>Busca um registro pelo id.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType<RegistroDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<RegistroDto>> Obter(
        string grupo, string entidade, Guid id, CancellationToken cancellationToken)
    {
        return Ok(await obterRegistro.ExecutarAsync(grupo, entidade, id, cancellationToken));
    }

    /// <summary>
    /// Substitui o registro inteiro (RN15). O corpo traz todos os campos e a "versao" devolvida pelo
    /// GET (RN12). Campo opcional ausente = campo removido.
    /// </summary>
    [HttpPut("{id:guid}")]
    [Consumes("application/json")]
    [ProducesResponseType<RegistroDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<RegistroDto>> Atualizar(
        string grupo, string entidade, Guid id, [FromBody] JsonObject dados, CancellationToken cancellationToken)
    {
        var registro = await atualizarRegistro.ExecutarAsync(grupo, entidade, id, dados, cancellationToken);

        logger.LogInformation("Registro {RegistroId} atualizado em {Grupo}/{Entidade}", id, grupo, entidade);
        return Ok(registro);
    }

    /// <summary>Exclui o registro, aplicando CASCATA e RESTRINGIR (RN16). 409 lista o que impede a exclusão.</summary>
    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Excluir(string grupo, string entidade, Guid id, CancellationToken cancellationToken)
    {
        await excluirRegistro.ExecutarAsync(grupo, entidade, id, cancellationToken);

        logger.LogInformation("Registro {RegistroId} excluído em {Grupo}/{Entidade}", id, grupo, entidade);
        return NoContent();
    }

    /// <summary>
    /// Aprova ou rejeita um registro PENDENTE (RN36): { "decisao": "APROVAR" | "REJEITAR", "justificativa": "..." }.
    /// Só o GESTOR da equipe do registro ou o ADMINISTRADOR. Justificativa de 10 a 1000 caracteres.
    /// </summary>
    [HttpPost("{id:guid}/aprovacao")]
    [Consumes("application/json")]
    [ProducesResponseType<RegistroDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status403Forbidden)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<RegistroDto>> Decidir(
        string grupo, string entidade, Guid id, [FromBody] DecisaoEntrada entrada, CancellationToken cancellationToken)
    {
        var registro = await decidirAprovacao.ExecutarAsync(grupo, entidade, id, entrada, cancellationToken);
        logger.LogInformation("Registro {RegistroId} em {Grupo}/{Entidade}: {Situacao}", id, grupo, entidade, registro.SituacaoAprovacao);
        return Ok(registro);
    }

    /// <summary>
    /// Histórico do registro, do mais recente para o mais antigo, com as mudanças por campo (RN32).
    /// Quem vê o registro vê o histórico; funciona também para registro já excluído.
    /// </summary>
    [HttpGet("{id:guid}/historico")]
    [ProducesResponseType<PaginaDto<HistoricoDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<PaginaDto<HistoricoDto>>> Historico(
        string grupo, string entidade, Guid id, [FromQuery] string? pagina, [FromQuery] string? tamanho,
        CancellationToken cancellationToken)
    {
        return Ok(await listarHistorico.ExecutarAsync(grupo, entidade, id, ParametrosDaUrl.Ler(Request), cancellationToken));
    }
}

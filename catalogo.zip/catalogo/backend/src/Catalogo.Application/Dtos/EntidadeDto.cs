namespace Catalogo.Application.Dtos;

// Metadados devolvidos para o front montar formulários. Só campos ATIVOS aparecem.

public sealed record EntidadeDto(
    Guid Id,
    string Chave,
    string Nome,
    string? Descricao,
    // Chave do campo usado como rótulo do registro em selects e listas.
    string? CampoExibicao,
    // true = cada registro pertence a uma equipe; false = registros globais, alterados só pelo administrador (RN27).
    bool EscopoEquipe,
    // A aprovação está ativa para a equipe informada em ?equipeId= (RN33). Nulo sem equipeId; false nas globais.
    bool? RequerAprovacao,
    // O formulário de avaliação ativo na equipe informada em ?equipeId= (RN40). Nulo sem equipeId ou sem modelo ativo.
    FormularioAvaliacaoDto? ModeloAvaliacao,
    IReadOnlyList<CampoDto> Campos,
    IReadOnlyList<RestricaoUnicaDto> RestricoesUnicas);

public sealed record CampoDto(
    Guid Id,
    string Chave,
    string Nome,
    // Texto igual ao do banco: TEXTO, TEXTO_LONGO, INTEIRO, DECIMAL, BOOLEANO, DATA, DATA_HORA, LISTA, REFERENCIA.
    string TipoDado,
    bool Obrigatorio,
    int Ordem,
    int? TamanhoMaximo,
    byte? Precisao,
    byte? Escala,
    IReadOnlyList<string>? Opcoes,
    // Chave da entidade apontada (só REFERENCIA).
    string? EntidadeReferenciada,
    // RESTRINGIR ou CASCATA (só REFERENCIA).
    string? AcaoExclusao,
    // Filtro das opções deste campo (RN08). Nulo se o campo não depende de outro.
    DependenciaDto? Dependencia,
    // Chave do campo DO FORMULÁRIO cujo valor o front envia em "dependeDe" ao buscar as opções (RN21).
    // Nulo se o campo não depende de outro.
    string? DependeDe);

/// <summary>
/// "As opções deste campo só mostram registros cujo <see cref="CampoAlvo"/> seja igual ao
/// <see cref="CampoOrigem"/> do registro escolhido em <see cref="CampoVia"/>"
/// (ou do próprio registro, se <see cref="CampoVia"/> for nulo). Valores são chaves de campo.
/// </summary>
public sealed record DependenciaDto(string? CampoVia, string CampoOrigem, string CampoAlvo);

public sealed record RestricaoUnicaDto(string Nome, IReadOnlyList<string> Campos);

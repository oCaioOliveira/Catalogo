using Catalogo.Application.Dtos;
using Catalogo.Domain.Acesso;
using Catalogo.Domain.Consultas;
using Catalogo.Domain.Historico;

namespace Catalogo.Application.Abstracoes;

/// <summary>Acesso aos usuários. Só os métodos que os casos de uso usam.</summary>
public interface IUsuarioRepository
{
    /// <summary>Usuário com os vínculos de equipe, para LEITURA ou ALTERAÇÃO (gravado no SaveChanges).</summary>
    Task<Usuario?> ObterPorIdAsync(Guid id, CancellationToken cancellationToken);

    /// <summary>Usuário pela matrícula (sem diferenciar maiúsculas), para alteração.</summary>
    Task<Usuario?> ObterPorMatriculaAsync(string matricula, CancellationToken cancellationToken);

    Task<bool> ExisteMatriculaAsync(string matricula, CancellationToken cancellationToken);

    /// <summary>Quantos administradores ativos existem (RN30).</summary>
    Task<int> ContarAdministradoresAtivosAsync(CancellationToken cancellationToken);

    /// <summary>Usuários filtrados, ordenados por nome, com os vínculos de equipe.</summary>
    Task<PaginaDe<Usuario>> ListarAsync(FiltroUsuarios filtro, Paginacao paginacao, CancellationToken cancellationToken);

    /// <summary>Id, matrícula e nome de vários usuários, numa consulta só.</summary>
    Task<IReadOnlyDictionary<Guid, UsuarioResumoDto>> ObterResumosAsync(IReadOnlyCollection<Guid> ids, CancellationToken cancellationToken);

    void Adicionar(Usuario usuario);
}

/// <summary>Filtros da listagem de usuários (todos opcionais, combinados com E).</summary>
public sealed record FiltroUsuarios(Guid? EquipeId, Perfil? Perfil, bool? Ativo);

/// <summary>Acesso às equipes.</summary>
public interface IEquipeRepository
{
    /// <summary>Equipe para leitura ou alteração (gravada no SaveChanges).</summary>
    Task<Equipe?> ObterPorIdAsync(Guid id, CancellationToken cancellationToken);

    Task<IReadOnlyList<Equipe>> ObterPorIdsAsync(IReadOnlyCollection<Guid> ids, CancellationToken cancellationToken);

    /// <summary>Equipes ordenadas por nome. <paramref name="ativa"/> nulo = todas.</summary>
    Task<IReadOnlyList<Equipe>> ListarAsync(bool? ativa, CancellationToken cancellationToken);

    /// <summary>Nome já usado (sem diferenciar maiúsculas nem acentos, pela collation)? Ignora a própria equipe.</summary>
    Task<bool> ExisteNomeAsync(string nome, Guid? ignorarEquipeId, CancellationToken cancellationToken);

    /// <summary>
    /// Usuários ativos não-administradores para quem esta é a ÚNICA equipe ativa: ficariam sem equipe
    /// se ela fosse desativada (RN31).
    /// </summary>
    Task<int> ContarUsuariosQueFicariamSemEquipeAsync(Guid equipeId, CancellationToken cancellationToken);

    void Adicionar(Equipe equipe);
}

/// <summary>Acesso ao histórico de alterações (RN32).</summary>
public interface IHistoricoRepository
{
    /// <summary>Marca a linha para gravação no MESMO SaveChanges da operação.</summary>
    void Adicionar(HistoricoAlteracao historico);

    /// <summary>
    /// Histórico de um alvo, do mais recente para o mais antigo. <paramref name="entidadeId"/> restringe
    /// a uma entidade (usado nas configurações, cujo alvo é a equipe).
    /// </summary>
    Task<PaginaDe<HistoricoAlteracao>> ListarAsync(
        AlvoHistorico alvoTipo, Guid alvoId, Paginacao paginacao, CancellationToken cancellationToken, Guid? entidadeId = null);

    /// <summary>Linha mais recente de um alvo (ex.: para saber a equipe de um registro já excluído).</summary>
    Task<HistoricoAlteracao?> ObterMaisRecenteAsync(AlvoHistorico alvoTipo, Guid alvoId, CancellationToken cancellationToken);
}

/// <summary>Uma página de itens e o total.</summary>
public sealed record PaginaDe<T>(IReadOnlyList<T> Itens, int Total);

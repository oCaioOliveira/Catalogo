using Catalogo.Domain.Aprovacao;

namespace Catalogo.Application.Abstracoes;

/// <summary>Configurações de uma entidade por equipe (RN33). Ausência de linha = tudo desativado.</summary>
public interface IConfiguracaoRepository
{
    /// <summary>Configuração para ALTERAÇÃO (gravada no SaveChanges), ou nula se não existe.</summary>
    Task<ConfiguracaoEntidadeEquipe?> ObterAsync(Guid entidadeId, Guid equipeId, CancellationToken cancellationToken);

    /// <summary>A aprovação está ativa para a entidade nesta equipe?</summary>
    Task<bool> RequerAprovacaoAsync(Guid entidadeId, Guid equipeId, CancellationToken cancellationToken);

    /// <summary>Entidades com aprovação ativa nesta equipe, numa consulta só.</summary>
    Task<IReadOnlySet<Guid>> EntidadesComAprovacaoAsync(Guid equipeId, CancellationToken cancellationToken);

    void Adicionar(ConfiguracaoEntidadeEquipe configuracao);
}

/// <summary>Filtros da fila de aprovação (todos opcionais, combinados com E).</summary>
/// <param name="EquipesPermitidas">Escopo de segurança: só pendentes destas equipes. Nulo = todas (ADMINISTRADOR).</param>
public sealed record FiltroPendentes(string? GrupoChave, string? EntidadeChave, Guid? EquipeId, IReadOnlySet<Guid>? EquipesPermitidas);

/// <summary>Um registro pendente na fila de aprovação, com o grupo e a entidade dele.</summary>
public sealed record PendenteResumo(
    Guid RegistroId, string GrupoChave, string EntidadeChave, string EntidadeNome, Guid? EquipeId, Guid? CriadoPorId, DateTime CriadoEm);

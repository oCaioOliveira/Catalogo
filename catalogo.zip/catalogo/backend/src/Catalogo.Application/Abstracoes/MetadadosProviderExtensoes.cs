using Catalogo.Domain.Excecoes;
using Catalogo.Domain.Metadados;

namespace Catalogo.Application.Abstracoes;

public static class MetadadosProviderExtensoes
{
    /// <summary>Grupo pela chave, ou <see cref="RecursoNaoEncontradoException"/>.</summary>
    public static async Task<Grupo> ObterGrupoOuFalharAsync(
        this IMetadadosProvider metadados, string grupoChave, CancellationToken cancellationToken)
    {
        return await metadados.ObterGrupoAsync(grupoChave, cancellationToken)
            ?? throw new RecursoNaoEncontradoException($"Grupo '{grupoChave}' não encontrado.");
    }

    /// <summary>Grupo e entidade pelas chaves, ou <see cref="RecursoNaoEncontradoException"/>.</summary>
    public static async Task<(Grupo Grupo, Entidade Entidade)> ObterEntidadeOuFalharAsync(
        this IMetadadosProvider metadados, string grupoChave, string entidadeChave, CancellationToken cancellationToken)
    {
        var grupo = await metadados.ObterGrupoOuFalharAsync(grupoChave, cancellationToken);

        var entidade = grupo.ObterEntidade(entidadeChave)
            ?? throw new RecursoNaoEncontradoException($"Entidade '{entidadeChave}' não encontrada no grupo '{grupo.Chave}'.");

        return (grupo, entidade);
    }
}

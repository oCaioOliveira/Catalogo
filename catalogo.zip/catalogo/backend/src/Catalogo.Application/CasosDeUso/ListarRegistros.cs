using Catalogo.Application.Abstracoes;
using Catalogo.Application.Comum;
using Catalogo.Application.Dtos;
using Catalogo.Domain.Acesso;
using Catalogo.Domain.Avaliacoes;
using Catalogo.Domain.Consultas;
using Catalogo.Domain.Excecoes;
using Catalogo.Domain.Metadados;

namespace Catalogo.Application.CasosDeUso;

/// <summary>
/// Caso de uso: listar registros com filtros, ordenação e paginação (RN17 a RN19).
/// Os parâmetros da URL são interpretados no Domain (<see cref="InterpretadorConsulta"/>) e a
/// consulta é feita em LINQ pela Infrastructure, SEMPRE com o escopo de equipes do usuário (RN26).
/// Lança <see cref="RecursoNaoEncontradoException"/>, <see cref="ValidacaoRegistroException"/> ou
/// <see cref="AcessoNegadoException"/>.
/// </summary>
public sealed class ListarRegistros(
    IUsuarioAtual usuarioAtual,
    IMetadadosProvider metadados,
    IRegistroRepository registros,
    IModeloAvaliacaoRepository modelos,
    MontadorRegistroDto montador)
{
    /// <param name="parametros">Todos os parâmetros da URL (um par por valor, inclusive repetidos).</param>
    public async Task<PaginaDto<RegistroDto>> ExecutarAsync(
        string grupoChave, string entidadeChave, IEnumerable<KeyValuePair<string, string>> parametros, CancellationToken cancellationToken)
    {
        var usuario = await usuarioAtual.ObterAsync(cancellationToken);
        var (_, entidade) = await metadados.ObterEntidadeOuFalharAsync(grupoChave, entidadeChave, cancellationToken);

        var lista = parametros.ToList();
        var criteriosAvaliacao = await CriteriosAvaliacaoAsync(usuario, entidade, lista, cancellationToken);
        var consulta = InterpretadorConsulta.Interpretar(entidade, lista, criteriosAvaliacao);

        // Escopo de segurança (RN26): entidades globais são vistas por todos; nas por equipe, o
        // não-administrador só vê as suas equipes. O filtro vai DENTRO da consulta, nunca em memória.
        if (!entidade.EhGlobal)
        {
            var visiveis = PoliticaPermissao.EquipesVisiveis(usuario);
            if (consulta.FiltroEquipe is Guid filtro && visiveis is not null && !visiveis.Contains(filtro))
                throw new AcessoNegadoException("Você não pertence a essa equipe.");

            consulta = consulta with { EquipesPermitidas = visiveis };
        }

        // RN37: o EXTERNO só vê registros não aprovados que ele mesmo criou. Também dentro da consulta.
        consulta = consulta with { NaoAprovadosSomenteDoAutor = PoliticaPermissao.NaoAprovadosSomenteDoAutor(usuario) };

        var pagina = await registros.ListarIdsAsync(entidade.Id, consulta, cancellationToken);

        // Carrega os registros da página e devolve na ordem da consulta.
        var porId = (await registros.ObterPorIdsAsync(pagina.Ids, cancellationToken)).ToDictionary(r => r.Id);
        var ordenados = pagina.Ids.Where(porId.ContainsKey).Select(id => porId[id]).ToList();
        var itens = await montador.MontarAsync(ordenados, entidade, cancellationToken);

        var paginacao = consulta.Paginacao;
        return new PaginaDto<RegistroDto>(itens, paginacao.Pagina, paginacao.Tamanho, pagina.Total, paginacao.TotalPaginas(pagina.Total));
    }

    /// <summary>
    /// RN48: critérios ESTRELAS ativos nos modelos ativos da entidade, nas equipes que o usuário vê. Só são
    /// buscados se a URL usa "avaliacao." (na ordenação ou num filtro).
    /// </summary>
    private async Task<IReadOnlySet<string>> CriteriosAvaliacaoAsync(
        UsuarioAtual usuario, Entidade entidade, IReadOnlyList<KeyValuePair<string, string>> parametros, CancellationToken cancellationToken)
    {
        var usaAvaliacao = parametros.Any(p =>
            p.Key.StartsWith(InterpretadorConsulta.PrefixoAvaliacao, StringComparison.Ordinal)
            || (p.Key == ChavesReservadas.Ordenacao && p.Value.Contains(InterpretadorConsulta.PrefixoAvaliacao, StringComparison.Ordinal)));
        if (!usaAvaliacao || entidade.EhGlobal)
            return new HashSet<string>();

        var ativos = await modelos.ListarAtivosAsync(entidade.Id, PoliticaPermissao.EquipesVisiveis(usuario)?.ToList(), cancellationToken);
        return ativos
            .SelectMany(m => m.CriteriosAtivos)
            .Where(c => c.Tipo == TipoCriterio.Estrelas)
            .Select(c => c.Chave)
            .ToHashSet(StringComparer.Ordinal);
    }
}

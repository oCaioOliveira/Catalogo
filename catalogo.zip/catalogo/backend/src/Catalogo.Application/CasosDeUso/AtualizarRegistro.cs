using System.Text.Json.Nodes;
using Catalogo.Application.Abstracoes;
using Catalogo.Application.Comum;
using Catalogo.Application.Dtos;
using Catalogo.Application.Mapeamentos;
using Catalogo.Domain.Acesso;
using Catalogo.Domain.Aprovacao;
using Catalogo.Domain.Excecoes;
using Catalogo.Domain.Historico;
using Catalogo.Domain.Metadados;
using Catalogo.Domain.Registros;
using Catalogo.Domain.Validacao;

namespace Catalogo.Application.CasosDeUso;

/// <summary>
/// Caso de uso: substituir um registro inteiro (PUT, RN15). O corpo traz TODOS os campos e a
/// "versao" lida no GET (RN12). Campo opcional ausente = campo removido. A equipe não muda.
/// Lança <see cref="RecursoNaoEncontradoException"/>, <see cref="AcessoNegadoException"/>,
/// <see cref="ValidacaoRegistroException"/>, <see cref="ConflitoConcorrenciaException"/> ou
/// <see cref="ConflitoUnicidadeException"/>.
/// </summary>
public sealed class AtualizarRegistro(
    IUsuarioAtual usuarioAtual,
    IMetadadosProvider metadados,
    IRegistroRepository registros,
    IUnidadeDeTrabalho unidadeDeTrabalho,
    PreparadorRegistro preparador,
    ContextoAprovacao contextoAprovacao,
    ServicoHistorico historico,
    MontadorRegistroDto montador,
    TimeProvider relogio)
{
    public async Task<RegistroDto> ExecutarAsync(
        string grupoChave, string entidadeChave, Guid id, JsonObject dados, CancellationToken cancellationToken)
    {
        var usuario = await usuarioAtual.ObterAsync(cancellationToken);
        var (grupo, entidade) = await metadados.ObterEntidadeOuFalharAsync(grupoChave, entidadeChave, cancellationToken);

        // 1. O registro precisa existir, ser desta entidade e visível (404) e o perfil precisa permitir (403).
        var registro = await registros.ObterParaAlteracaoAsync(id, cancellationToken);
        var descricao = $"Registro {id} em '{entidade.Nome}'";
        if (registro is null || registro.EntidadeId != entidade.Id)
            throw new RecursoNaoEncontradoException($"{descricao} não encontrado.");
        // Com aprovação ativa, o EXTERNO altera só os seus registros PENDENTES ou REJEITADOS (RN35).
        var alvo = await contextoAprovacao.ExistenteAsync(entidade, registro, cancellationToken);
        Permissoes.Exigir(PoliticaPermissao.Decidir(usuario, OperacaoRegistro.Alterar, alvo), descricao);

        // 2. Concorrência (RN12): a versão lida pelo cliente precisa ser a atual...
        var versaoLida = LerVersao(dados);
        if (!versaoLida.AsSpan().SequenceEqual(registro.Versao))
        {
            throw new ConflitoConcorrenciaException(
                "O registro foi alterado por outra pessoa depois que você o leu. Recarregue e tente de novo.");
        }

        // ... e continua protegida até a gravação: o UPDATE só acontece se a Versao no banco ainda for essa.
        registros.DefinirVersaoEsperada(registro, versaoLida);

        // A equipe de um registro não muda (RN27).
        ConferirEquipeInalterada(dados, registro.EquipeId);

        // 3. A mesma validação do criar, com a equipe do registro. O próprio registro não conflita consigo.
        var preparado = await preparador.PrepararAsync(
            grupo, entidade, dados, registro.Id, registro.EquipeId, usuario, registro.CriadoPorId ?? usuario.Id, cancellationToken);

        // 4. Substitui Dados e sincroniza referências, valores tipados e chaves únicas.
        var antes = registro.ParaJsonPlano(entidade);
        SincronizadorRegistro.Aplicar(registro, entidade, preparado.Validado, preparado.ChavesUnicas);

        // RN35: o EXTERNO autor alterando um REJEITADO faz um REENVIO (volta para PENDENTE).
        var situacaoAntes = registro.SituacaoAprovacao;
        registro.SituacaoAprovacao = FluxoAprovacao.SituacaoAposAlteracao(usuario, registro);

        // 5. Grava tudo, com o histórico, num único SaveChanges.
        registro.AtualizadoEm = relogio.GetUtcNow().UtcDateTime;
        registro.AtualizadoPorId = usuario.Id;
        var depois = registro.ParaJsonPlano(entidade);
        if (registro.SituacaoAprovacao != situacaoAntes)
        {
            // O reenvio aparece no histórico como a mudança de situação, junto com os campos.
            antes["situacaoAprovacao"] = AprovacaoConversor.ParaTexto(situacaoAntes);
            depois["situacaoAprovacao"] = AprovacaoConversor.ParaTexto(registro.SituacaoAprovacao);
        }
        historico.RegistrarRegistro(OperacaoHistorico.Alteracao, registro, usuario, Guid.NewGuid(), antes, depois);

        try
        {
            await unidadeDeTrabalho.SalvarAlteracoesAsync(cancellationToken);
        }
        catch (ViolacaoUnicidadeBancoException ex)
        {
            throw PreparadorRegistro.ConverterViolacao(entidade, ex);
        }

        return await montador.MontarAsync(registro, entidade, cancellationToken);
    }

    /// <summary>A "versao" vem no corpo, em Base64, igual ao que o GET devolve.</summary>
    private static byte[] LerVersao(JsonObject dados)
    {
        var erros = new ErrosPorCampo();
        byte[]? versao = null;

        if (!dados.TryGetPropertyValue(ChavesReservadas.Versao, out var no) || no is not JsonValue valor
            || !valor.TryGetValue<string>(out var texto) || string.IsNullOrWhiteSpace(texto))
        {
            erros.Adicionar(ChavesReservadas.Versao, "Obrigatória: envie a \"versao\" devolvida pelo GET do registro.");
        }
        else
        {
            try
            {
                versao = Convert.FromBase64String(texto);
            }
            catch (FormatException)
            {
                erros.Adicionar(ChavesReservadas.Versao, "Inválida: envie a \"versao\" exatamente como o GET devolveu.");
            }
        }

        erros.LancarSeHouverErros();
        return versao!;
    }

    /// <summary>"equipeId" no corpo do PUT é aceito só se for a mesma equipe (o front pode reenviar o que leu).</summary>
    private static void ConferirEquipeInalterada(JsonObject dados, Guid? equipeAtual)
    {
        var informada = ResolvedorEquipe.LerDoCorpo(dados);
        if (informada is null || (Guid.TryParse(informada, out var id) && id == equipeAtual))
            return;

        var erros = new ErrosPorCampo();
        erros.Adicionar(ChavesReservadas.EquipeId, "A equipe de um registro não pode ser alterada.");
        erros.LancarSeHouverErros();
    }
}

using System.Text.Json.Nodes;
using Catalogo.Application.Abstracoes;
using Catalogo.Application.Comum;
using Catalogo.Application.Dtos;
using Catalogo.Application.Mapeamentos;
using Catalogo.Domain.Acesso;
using Catalogo.Domain.Aprovacao;
using Catalogo.Domain.Excecoes;
using Catalogo.Domain.Historico;
using Catalogo.Domain.Registros;

namespace Catalogo.Application.CasosDeUso;

/// <summary>
/// Caso de uso: criar um registro numa entidade. Fluxo descrito em docs/arquitetura.md.
/// Lança <see cref="RecursoNaoEncontradoException"/>, <see cref="ValidacaoRegistroException"/>,
/// <see cref="AcessoNegadoException"/> ou <see cref="ConflitoUnicidadeException"/>.
/// </summary>
public sealed class CriarRegistro(
    IUsuarioAtual usuarioAtual,
    IMetadadosProvider metadados,
    IRegistroRepository registros,
    IUnidadeDeTrabalho unidadeDeTrabalho,
    ResolvedorEquipe resolvedorEquipe,
    ContextoAprovacao contextoAprovacao,
    PreparadorRegistro preparador,
    ServicoHistorico historico,
    MontadorRegistroDto montador)
{
    public async Task<RegistroDto> ExecutarAsync(
        string grupoChave, string entidadeChave, JsonObject dados, CancellationToken cancellationToken)
    {
        var usuario = await usuarioAtual.ObterAsync(cancellationToken);

        // 1. Metadados da entidade.
        var (grupo, entidade) = await metadados.ObterEntidadeOuFalharAsync(grupoChave, entidadeChave, cancellationToken);

        // 2. Equipe do registro (chave reservada "equipeId", RN27) e permissão de criar (RN26), considerando
        //    a aprovação da entidade nessa equipe: com ela ativa, o EXTERNO também cria (RN34).
        var equipeId = await resolvedorEquipe.ResolverAsync(usuario, entidade, ResolvedorEquipe.LerDoCorpo(dados), cancellationToken);
        var alvo = await contextoAprovacao.NovoAsync(entidade, equipeId, cancellationToken);
        Permissoes.Exigir(PoliticaPermissao.Decidir(usuario, OperacaoRegistro.Criar, alvo), $"Equipe {equipeId}");

        // 3 a 7. Validação completa (campos, referências, equipes, dependências) e verificação prévia de unicidade.
        var preparado = await preparador.PrepararAsync(
            grupo, entidade, dados, registroAtualId: null, equipeId, usuario, autorDoRegistro: usuario.Id, cancellationToken);

        // Dados, referências, valores tipados e chaves únicas, gravados juntos num único SaveChanges.
        var registro = new Registro
        {
            EquipeId = equipeId,
            CriadoPorId = usuario.Id,
            // RN34: EXTERNO com aprovação ativa → PENDENTE; os demais → APROVADO.
            SituacaoAprovacao = FluxoAprovacao.SituacaoInicial(usuario, alvo.RequerAprovacao),
        };
        SincronizadorRegistro.Aplicar(registro, entidade, preparado.Validado, preparado.ChavesUnicas);
        registros.Adicionar(registro);

        // Histórico no mesmo SaveChanges (RN32). O Id do registro já foi gerado ao adicionar.
        historico.RegistrarRegistro(OperacaoHistorico.Criacao, registro, usuario, Guid.NewGuid(),
            antes: null, depois: registro.ParaJsonPlano(entidade));

        try
        {
            await unidadeDeTrabalho.SalvarAlteracoesAsync(cancellationToken);
        }
        catch (ViolacaoUnicidadeBancoException ex)
        {
            // Corrida: outra requisição gravou o mesmo valor ao mesmo tempo.
            throw PreparadorRegistro.ConverterViolacao(entidade, ex);
        }

        return await montador.MontarAsync(registro, entidade, cancellationToken);
    }
}

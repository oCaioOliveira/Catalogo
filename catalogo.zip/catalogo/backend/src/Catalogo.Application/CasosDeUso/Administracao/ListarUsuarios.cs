using Catalogo.Application.Abstracoes;
using Catalogo.Application.Comum;
using Catalogo.Application.Dtos;
using Catalogo.Application.Mapeamentos;
using Catalogo.Domain.Acesso;
using Catalogo.Domain.Consultas;
using Catalogo.Domain.Validacao;

namespace Catalogo.Application.CasosDeUso.Administracao;

/// <summary>Caso de uso: listar usuários (só ADMINISTRADOR), com filtros por equipe, perfil e ativo.</summary>
public sealed class ListarUsuarios(IUsuarioAtual usuarioAtual, IUsuarioRepository usuarios, IEquipeRepository equipes)
{
    /// <param name="parametros">Parâmetros da URL: equipeId, perfil, ativo, pagina, tamanho.</param>
    public async Task<PaginaDto<UsuarioDto>> ExecutarAsync(
        IEnumerable<KeyValuePair<string, string>> parametros, CancellationToken cancellationToken)
    {
        Permissoes.ExigirAdministrador(await usuarioAtual.ObterAsync(cancellationToken));

        var lista = parametros.ToList();
        var erros = new ErrosPorCampo();
        var paginacao = InterpretadorConsulta.InterpretarPaginacao(lista, erros);

        Guid? equipeId = null;
        if (InterpretadorConsulta.LerUnico(lista, "equipeId", erros) is string textoEquipe)
        {
            if (Guid.TryParseExact(textoEquipe.Trim(), "D", out var id))
                equipeId = id;
            else
                erros.Adicionar("equipeId", "Deve ser o id (GUID) de uma equipe.");
        }

        Perfil? perfil = null;
        if (InterpretadorConsulta.LerUnico(lista, "perfil", erros) is string textoPerfil)
            perfil = ValidacaoUsuario.LerPerfil(textoPerfil, erros);

        bool? ativo = null;
        if (InterpretadorConsulta.LerUnico(lista, "ativo", erros) is string textoAtivo)
        {
            if (bool.TryParse(textoAtivo, out var valor))
                ativo = valor;
            else
                erros.Adicionar("ativo", "Deve ser true ou false.");
        }

        erros.LancarSeHouverErros();

        var pagina = await usuarios.ListarAsync(new FiltroUsuarios(equipeId, perfil, ativo), paginacao, cancellationToken);
        var equipesPorId = await ValidacaoUsuario.EquipesDosUsuariosAsync(equipes, pagina.Itens, cancellationToken);

        return new PaginaDto<UsuarioDto>(
            pagina.Itens.Select(u => u.ParaDto(equipesPorId)).ToList(),
            paginacao.Pagina, paginacao.Tamanho, pagina.Total, paginacao.TotalPaginas(pagina.Total));
    }
}

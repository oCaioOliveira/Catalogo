using Catalogo.Application.Abstracoes;
using Catalogo.Application.Comum;
using Catalogo.Application.Dtos;
using Catalogo.Application.Mapeamentos;

namespace Catalogo.Application.CasosDeUso.Administracao;

/// <summary>Caso de uso: listar equipes (só ADMINISTRADOR), ordenadas por nome. <c>ativa</c> nulo = todas.</summary>
public sealed class ListarEquipes(IUsuarioAtual usuarioAtual, IEquipeRepository equipes)
{
    public async Task<IReadOnlyList<EquipeDto>> ExecutarAsync(bool? ativa, CancellationToken cancellationToken)
    {
        Permissoes.ExigirAdministrador(await usuarioAtual.ObterAsync(cancellationToken));
        return (await equipes.ListarAsync(ativa, cancellationToken)).Select(e => e.ParaDto()).ToList();
    }
}

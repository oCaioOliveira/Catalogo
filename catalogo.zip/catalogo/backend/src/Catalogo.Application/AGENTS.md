# AGENTS.md — Catalogo.Application

Complementa o [`AGENTS.md` da raiz](../../AGENTS.md). O fluxo completo de uma criação está em
[`docs/arquitetura.md`](../../../docs/arquitetura.md#fluxo-de-uma-criação-de-registro).

## O que fica aqui

| Pasta | Conteúdo |
|---|---|
| `CasosDeUso/` | um caso de uso por classe. Registros na raiz (`CriarRegistro`, `ListarRegistros`...); `Acesso/` (login, troca de senha, "eu", primeiro administrador); `Administracao/` (equipes e usuários); `Historico/`; `Aprovacao/` (configuração, decisão e fila de pendentes); `Avaliacoes/` (modelos de avaliação, avaliar, resumo, histórico) |
| `Comum/` | peças usadas por mais de um caso de uso: `PreparadorRegistro` (validação completa de criar **e** atualizar), `MontadorRegistroDto`, `ResolvedorEquipe` (equipe do registro, RN27), `Permissoes` (decisão → 404/403), `ServicoHistorico`, `MontadorHistorico`, `ContextoAprovacao` (monta o `RegistroAlvo` com a situação de aprovação), `ConfiguracaoDaEquipe` (quem configura uma equipe, usado pela aprovação e pela avaliação), `MontadorModeloAvaliacao` e `ProvedorIdentidadeLocal` |
| `Abstracoes/` | **interfaces** implementadas pela Infrastructure ou pela Api: `IMetadadosProvider`, `IRegistroRepository`, `IUnidadeDeTrabalho`, `IUsuarioRepository`, `IEquipeRepository`, `IHistoricoRepository`, `IConfiguracaoRepository`, `IModeloAvaliacaoRepository`, `IAvaliacaoRepository`, `IUsuarioAtual`, `ISituacaoUsuarios`, `IProvedorIdentidade`, `IHasherSenha`, `IGeradorToken` |
| `Dtos/` | o que entra e sai da API (`record`s) |
| `Mapeamentos/` | conversão manual Domain → DTO, com métodos de extensão `ParaDto(...)` |

Este projeto depende **só** do Domain, sem nenhum pacote. Garantido por `Application_SoDependeDoDomain`.
Relógio: use `TimeProvider` (da BCL, injetado), nunca `DateTime.Now` direto.

## Como criar um caso de uso

1. Crie `CasosDeUso/NomeDoCasoDeUso.cs`: uma classe `sealed` com construtor primário recebendo as
   interfaces de que precisa e **um** método público `ExecutarAsync(..., CancellationToken)`.
   Use `ObterRegistro.cs` como modelo.
2. Precisa de algo do banco que ainda não existe? Adicione **só o método necessário** na interface
   de `Abstracoes/` (não crie repositório genérico) e implemente na Infrastructure.
3. Registre em `src/Catalogo.Api/Configuracao/ConfiguracaoAplicacao.cs` (`AddScoped<NomeDoCasoDeUso>()`).
4. Injete no controller pelo construtor. **Não use mediator** ([adr/0004](../../../docs/adr/0004-sem-mediatr-automapper-fluentassertions.md)).
5. Escreva os testes em `tests/Catalogo.Application.Tests/CasosDeUso/`, usando os dublês de `Dubles/`.

## Todo caso de uso que lê ou altera dados consulta a permissão e grava histórico

1. Pegue quem está fazendo: `var usuario = await usuarioAtual.ObterAsync(ct);`.
2. Pergunte à política e traduza. Em registros, monte o alvo pelo `ContextoAprovacao`, que já considera a
   **situação de aprovação**, o autor e se a aprovação está ativa (RN33 a RN37):
   `var alvo = await aprovacao.ExistenteAsync(entidade, registro, ct);`
   `Permissoes.Exigir(PoliticaPermissao.Decidir(usuario, OperacaoRegistro.Alterar, alvo), descricao);`
   (404 se não vê, RN28 e RN37; 403 se o perfil não permite). Na criação, `aprovacao.NovoAsync(...)`.
   Administração: `Permissoes.ExigirAdministrador(usuario)`.
3. Listagens: passe o escopo para a consulta (`EquipesPermitidas = PoliticaPermissao.EquipesVisiveis(usuario)` e
   `NaoAprovadosSomenteDoAutor = PoliticaPermissao.NaoAprovadosSomenteDoAutor(usuario)`). Nunca filtre em memória.
4. Alterou dados? Chame o `ServicoHistorico` **antes** do `SalvarAlteracoesAsync`, com o objeto plano
   de antes e de depois (`ParaJsonPlano`, `ParaJsonHistorico`). Nunca coloque senha ou hash nesses objetos (RN32).
5. Mudou usuário ou equipe? Chame `ISituacaoUsuarios.Invalidar`/`InvalidarTodos` depois de salvar, para valer na hora.

Modelos: `AtualizarRegistro.cs` (registro, inclusive o reenvio), `DecidirAprovacao.cs` (decisão) e `AtualizarUsuario.cs` (administração).

Avaliação: `AvaliarRegistro.cs` (quem → modelo ativo → situação → respostas). Médias e contagens são do
repositório (no banco); o caso de uso só monta o DTO. Configurações de equipe começam por `ConfiguracaoDaEquipe.ValidarAsync`.

Casos de uso de escrita **consideram a situação de aprovação via política central**: nunca teste
`SituacaoAprovacao` ou perfil diretamente para decidir permissão. Transições de situação ficam em `FluxoAprovacao` (Domain).

## Não duplique regra entre casos de uso

- Validar e preparar um registro (RN01 a RN09) → `PreparadorRegistro.PrepararAsync`.
- Gravar os dados num `Registro` → `SincronizadorRegistro.Aplicar` (Domain), que mantém `RegistroValor` junto.
- Devolver registros → `MontadorRegistroDto.MontarAsync` (busca rótulos, autores e médias das avaliações em lote, RN20 e RN48). Nunca busque por linha.
- Validar respostas de avaliação → `RegrasAvaliacao.ValidarRespostas` (Domain); validar modelo → `RegrasModeloAvaliacao`.
- Interpretar parâmetros de URL → `InterpretadorConsulta` (Domain).

## Mapeamento

- Sempre manual, num método de extensão em `Mapeamentos/` (ex.: `registro.ParaDto(entidade)`).
- Nunca devolva classes do Domain na API: sempre um DTO.
- Registros são **planos** para o cliente: `RegistroDto.Dados` junta campos simples e referências (RN07),
  e cada referência sai como `{ id, rotulo }` (RN20).

## Qual exceção lançar

| Situação | Exceção (de `Catalogo.Domain.Excecoes`) |
|---|---|
| Grupo, entidade ou registro não existe | `RecursoNaoEncontradoException`. Use `metadados.ObterEntidadeOuFalharAsync(...)` |
| Dados inválidos (um ou vários campos) | `ValidacaoRegistroException`. Junte com `ErrosPorCampo` e chame `LancarSeHouverErros()` (RN05) |
| Valor já usado numa restrição única | `ConflitoUnicidadeException` (RN09) |
| `IUnidadeDeTrabalho` lançou `ViolacaoUnicidadeBancoException` | converta em `ConflitoUnicidadeException` (ver passo 7 de `CriarRegistro`) |
| Registro alterado por outra pessoa (`versao` diferente) | `ConflitoConcorrenciaException` (RN12). Também é lançada pela `IUnidadeDeTrabalho` |
| Exclusão impedida por RESTRINGIR | `ExclusaoBloqueadaException` com as `DependenciaBloqueante` (RN16) |
| Parâmetro de URL inválido (filtro, ordenação, página) | `ValidacaoRegistroException`, com a chave = nome do parâmetro (RN18) |
| Registro que o usuário não pode ver | `RecursoNaoEncontradoException` (RN28), via `Permissoes.Exigir` |
| Perfil não permite a operação | `AcessoNegadoException` (403), via `Permissoes.Exigir` |
| Credenciais inválidas, usuário desativado | `NaoAutenticadoException` (401). No login, mensagem sempre genérica (RN23) |
| Regra que impede a operação (último administrador, equipe com usuários, registro não pendente) | `RegraDeNegocioException` com `Codigo` (409). Dados extras (ex.: `quantidade`) vão no terceiro parâmetro e saem no ProblemDetails |

## Regras deste projeto

- Grave tudo de um caso de uso com **uma** chamada a `IUnidadeDeTrabalho.SalvarAlteracoesAsync`.
  A exceção é a exclusão: `IRegistroRepository.ExcluirAsync` executa o plano na hora, na própria transação.
- Metadados vêm do `IMetadadosProvider` (com cache) e **não podem ser alterados**.
- `try/catch` aqui só para **traduzir** uma exceção (como no passo 7). Nunca para esconder erro.

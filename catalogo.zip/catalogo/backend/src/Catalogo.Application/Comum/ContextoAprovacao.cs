using Catalogo.Application.Abstracoes;
using Catalogo.Domain.Acesso;
using Catalogo.Domain.Metadados;
using Catalogo.Domain.Registros;

namespace Catalogo.Application.Comum;

/// <summary>
/// Monta o <see cref="RegistroAlvo"/> que a <see cref="PoliticaPermissao"/> precisa, com a informação
/// de aprovação ativa lida da configuração da entidade na equipe do registro (RN33).
/// A REGRA continua toda na política; aqui só se busca o dado.
/// </summary>
public sealed class ContextoAprovacao(IConfiguracaoRepository configuracoes)
{
    /// <summary>Aprovação ativa para a entidade nesta equipe? Sempre falso em entidades globais.</summary>
    public async Task<bool> RequerAprovacaoAsync(Entidade entidade, Guid? equipeId, CancellationToken cancellationToken) =>
        !entidade.EhGlobal && equipeId is Guid equipe && await configuracoes.RequerAprovacaoAsync(entidade.Id, equipe, cancellationToken);

    public async Task<RegistroAlvo> NovoAsync(Entidade entidade, Guid? equipeId, CancellationToken cancellationToken) =>
        RegistroAlvo.Novo(entidade, equipeId, await RequerAprovacaoAsync(entidade, equipeId, cancellationToken));

    public async Task<RegistroAlvo> ExistenteAsync(Entidade entidade, Registro registro, CancellationToken cancellationToken) =>
        RegistroAlvo.De(entidade, registro, await RequerAprovacaoAsync(entidade, registro.EquipeId, cancellationToken));
}

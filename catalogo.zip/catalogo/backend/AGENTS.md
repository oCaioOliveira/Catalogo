# AGENTS.md — backend

Complementa o [`AGENTS.md` da raiz](../AGENTS.md). Cada projeto tem o seu próprio `AGENTS.md`:
leia sempre o mais próximo do código que você vai mudar. **Todos os comandos e caminhos daqui são
relativos a `backend/`.**

API .NET 8 em Clean Architecture enxuta ([ADR 0002](../docs/adr/0002-clean-architecture-enxuta.md)).
Visão geral e fluxos em [`docs/arquitetura.md`](../docs/arquitetura.md).

## Mapa

| Caminho | O que tem | Leia antes de mexer |
|---|---|---|
| `src/Catalogo.Domain/` | motor genérico: metadados, validadores, chave única, plano de exclusão, filtros, **política de permissões**, histórico | [`src/Catalogo.Domain/AGENTS.md`](src/Catalogo.Domain/AGENTS.md) |
| `src/Catalogo.Application/` | casos de uso, DTOs, mapeamentos, interfaces | [`src/Catalogo.Application/AGENTS.md`](src/Catalogo.Application/AGENTS.md) |
| `src/Catalogo.Infrastructure/` | EF Core, repositório, consultas LINQ, cache de metadados | [`src/Catalogo.Infrastructure/AGENTS.md`](src/Catalogo.Infrastructure/AGENTS.md) |
| `src/Catalogo.Api/` | controllers, autenticação JWT, erros, OpenAPI, DI, configuração | [`src/Catalogo.Api/AGENTS.md`](src/Catalogo.Api/AGENTS.md) |
| `tests/` | testes de unidade, arquitetura e integração | [`tests/AGENTS.md`](tests/AGENTS.md) |

## Comandos

Rode **de dentro de `backend/`**:

```bash
# Subir o SQL Server local (cria/atualiza os bancos ListagemGenerica e ListagemGenerica_Testes)
(cd ../database/docker && docker compose --env-file ../.env up -d)

# Build (precisa sair com 0 warnings)
dotnet build

# Todos os testes (os de integração precisam do banco no ar e do user-secret, ver README.md)
dotnet test

# Só os testes que não usam banco
dotnet test --filter "FullyQualifiedName!~IntegrationTests"

# Rodar a API (Swagger UI em http://localhost:5080/swagger)
dotnet run --project src/Catalogo.Api --launch-profile Development
```

## Regras do back-end

1. **Regra de dependência**: `Application → Domain`; `Infrastructure → Application, Domain`;
   `Api → Application`, e `Api → Infrastructure` só no `Program.cs`. O Domain não depende de nada.
   Garantido por `tests/Catalogo.ArchitectureTests/DependenciasEntreCamadasTests.cs`.
2. **Pacotes proibidos**: MediatR, AutoMapper, MassTransit e FluentAssertions ≥ 8
   ([ADR 0004](../docs/adr/0004-sem-mediatr-automapper-fluentassertions.md)). Versões de pacote só em
   `Directory.Packages.props`. Garantido por `PacotesTests`. Pacote novo fora da lista do
   [README](README.md#pacotes) **precisa de aprovação antes**.
3. **Não há migrations**: o schema vem de `../database/scripts/V00x__*.sql`. Nunca use `dotnet ef
   migrations`, `EnsureCreated`, `EnsureDeleted` ou `Migrate`
   ([ADR 0003](../docs/adr/0003-schema-por-scripts-sql.md)). Garantido por `SemMigrationsTests`.
4. **Toda consulta ao banco é EF Core em LINQ**: proibido `SqlQueryRaw`, `FromSql*`, `ExecuteSql*` e
   Dapper ([ADR 0011](../docs/adr/0011-consultas-somente-linq.md)). Garantido por `SemSqlManualTests`.
5. **Segredos**: connection string (`ConnectionStrings:Catalogo`) e chave do JWT (`Jwt:ChaveAssinatura`)
   ficam vazias nos `appsettings*.json`. O valor vem do user-secrets (desenvolvimento) ou de variáveis de
   ambiente (servidores). Ver [`docs/seguranca.md`](../docs/seguranca.md).
6. **Permissão e histórico**: toda regra de "quem pode" está na `PoliticaPermissao` (Domain), inclusive as de
   aprovação (RN33 a RN38) e de avaliação (RN40, RN44, RN47), e todo caso de uso que altera dados grava histórico (RN26, RN32). Detalhes no AGENTS.md da Application.
7. **Senha nunca** em log, resposta, histórico ou exceção. `SenhaHash` não sai da Infrastructure/Domain:
   nenhum DTO o expõe (o teste `RespostasEHistoricoDeUsuarios_NuncaTrazemSenhaNemHash` confere no JSON bruto).
8. **Nomes**: domínio em português (`CriarRegistro`, `Campo.Obrigatorio`); termos do framework em
   inglês (`Controller`, `DbContext`, `IExceptionHandler`).
9. Ao implementar ou testar uma regra, cite o `RNxx` de [`docs/regras-de-negocio.md`](../docs/regras-de-negocio.md).

## Definição de pronto

- [ ] `dotnet build` sem nenhum warning (`TreatWarningsAsErrors` está ligado).
- [ ] `dotnet test` todo verde, inclusive os testes de integração.
- [ ] Código novo coberto por teste no projeto certo (ver [`tests/AGENTS.md`](tests/AGENTS.md)).
- [ ] Se uma regra mudou: `docs/regras-de-negocio.md` (ou o doc de `docs/` correspondente) atualizado no mesmo PR.
- [ ] Se uma decisão de arquitetura mudou: ADR novo em `docs/adr/`.
- [ ] Se o schema mudou: script `V00x` novo em `database/scripts/` **e** mapeamento do EF atualizado.

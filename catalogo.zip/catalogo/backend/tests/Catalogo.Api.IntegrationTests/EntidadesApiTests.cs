using System.Net;
using Catalogo.Api.IntegrationTests.Apoio;

namespace Catalogo.Api.IntegrationTests;

public class EntidadesApiTests(BancoDeTestesFixture banco) : TesteDeApi(banco)
{
    [Fact]
    public async Task Get_GrupoTestesDesempenho_DevolveAs10EntidadesEOs40CamposDoSeed()
    {
        var resposta = await Cliente.GetAsync($"{UrlGrupo}/entidades");

        Assert.Equal(HttpStatusCode.OK, resposta.StatusCode);
        var entidades = (await LerJson(resposta)).AsArray();
        Assert.Equal(10, entidades.Count);
        Assert.Equal(40, entidades.Sum(e => e!["campos"]!.AsArray().Count));
    }

    [Fact]
    public async Task Get_CenarioTeste_TrazADependenciaDoEndpointEAUnicidadeComposta()
    {
        var entidades = (await LerJson(await Cliente.GetAsync($"{UrlGrupo}/entidades"))).AsArray();
        var cenario = entidades.Single(e => e!["chave"]!.GetValue<string>() == "cenario_teste")!;
        var endpoint = cenario["campos"]!.AsArray().Single(c => c!["chave"]!.GetValue<string>() == "endpoint_servico")!;

        Assert.Equal("REFERENCIA", endpoint["tipoDado"]!.GetValue<string>());
        Assert.Equal("relatorio_teste", endpoint["dependencia"]!["campoVia"]!.GetValue<string>());
        Assert.Equal("projeto", endpoint["dependencia"]!["campoOrigem"]!.GetValue<string>());
        Assert.Equal("projeto", endpoint["dependencia"]!["campoAlvo"]!.GetValue<string>());

        var restricao = Assert.Single(cenario["restricoesUnicas"]!.AsArray())!;
        Assert.Equal("uq_cenario_relatorio_numero", restricao["nome"]!.GetValue<string>());
        Assert.Equal(["relatorio_teste", "numero_cenario"], restricao["campos"]!.AsArray().Select(c => c!.GetValue<string>()));
    }

    [Fact]
    public async Task Get_ChaveDoGrupoEmMaiusculas_EncontraOGrupo()
    {
        // A collation do banco não diferencia maiúsculas.
        var resposta = await Cliente.GetAsync("/api/grupos/TESTES_DESEMPENHO/entidades");

        Assert.Equal(HttpStatusCode.OK, resposta.StatusCode);
    }

    [Fact]
    public async Task Get_GrupoInexistente_Devolve404()
    {
        var resposta = await Cliente.GetAsync("/api/grupos/nao_existe/entidades");

        Assert.Equal(HttpStatusCode.NotFound, resposta.StatusCode);
    }
}

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Respawn;
using Respawn.Graph;

namespace Catalogo.Api.IntegrationTests.Apoio;

/// <summary>
/// Sobe a API em memória apontando para o banco de TESTES (ListagemGenerica_Testes, criado pelo
/// db-init em database/docker) e prepara o Respawn para limpar os dados entre os testes.
/// É criado uma vez para a coleção "Api" inteira.
/// </summary>
public sealed class BancoDeTestesFixture : IAsyncLifetime
{
    /// <summary>Chave da connection string do banco de testes (user-secrets deste projeto ou variável de ambiente).</summary>
    public const string NomeConnectionString = "CatalogoTestes";

    // Só os DADOS são apagados (registros, usuários, equipes e histórico).
    // Metadados (Grupo, Entidade, Campo...) vêm do seed dos scripts e ficam.
    private static readonly Table[] TabelasDeDados =
    [
        new("dbo", "AvaliacaoResposta"),
        new("dbo", "Avaliacao"),
        new("dbo", "CriterioAvaliacao"),
        new("dbo", "ModeloAvaliacao"),
        new("dbo", "RegistroChaveUnica"),
        new("dbo", "RegistroReferencia"),
        new("dbo", "RegistroValor"),
        new("dbo", "Registro"),
        new("dbo", "HistoricoAlteracao"),
        new("dbo", "ConfiguracaoEntidadeEquipe"),
        new("dbo", "UsuarioEquipe"),
        new("dbo", "Usuario"),
        new("dbo", "Equipe"),
    ];

    /// <summary>Chave do JWT só dos testes (aleatória a cada execução).</summary>
    private static readonly string ChaveJwtDosTestes = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(48));

    private Respawner _respawner = null!;

    public string ConnectionString { get; } = LerConnectionString();

    public WebApplicationFactory<Program> Fabrica { get; private set; } = null!;

    public async Task InitializeAsync()
    {
        Fabrica = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            // Ambiente próprio: não carrega o user-secrets da Api (que aponta para o banco de desenvolvimento).
            builder.UseEnvironment("Testes");
            builder.UseSetting("ConnectionStrings:Catalogo", ConnectionString);
            builder.UseSetting("Jwt:ChaveAssinatura", ChaveJwtDosTestes);
            // Os testes fazem muitos logins seguidos do mesmo "endereço": o limite de produção atrapalharia.
            builder.UseSetting("Seguranca:LoginLimitePorMinuto", "100000");
        });

        await using var conexao = new SqlConnection(ConnectionString);
        await conexao.OpenAsync();
        _respawner = await Respawner.CreateAsync(conexao, new RespawnerOptions
        {
            DbAdapter = DbAdapter.SqlServer,
            TablesToInclude = TabelasDeDados,
        });
    }

    /// <summary>Apaga os dados (não os metadados). Chamado antes de cada teste.</summary>
    public async Task LimparDadosAsync()
    {
        await using var conexao = new SqlConnection(ConnectionString);
        await conexao.OpenAsync();
        await _respawner.ResetAsync(conexao);
    }

    public async Task DisposeAsync() => await Fabrica.DisposeAsync();

    private static string LerConnectionString()
    {
        var configuracao = new ConfigurationBuilder()
            .AddUserSecrets<BancoDeTestesFixture>(optional: true)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuracao.GetConnectionString(NomeConnectionString);
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                $"Configure 'ConnectionStrings:{NomeConnectionString}' (user-secrets do projeto de testes de " +
                $"integração ou variável de ambiente ConnectionStrings__{NomeConnectionString}). Ver README.md.");
        }

        // Proteção: o Respawn APAGA dados. Nunca rode contra um banco que não seja o de testes.
        var banco = new SqlConnectionStringBuilder(connectionString).InitialCatalog;
        if (!banco.EndsWith("_Testes", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Os testes de integração apagam dados e só rodam num banco terminado em '_Testes' (configurado: '{banco}').");
        }

        return connectionString;
    }
}

[CollectionDefinition(Nome)]
public sealed class ColecaoApi : ICollectionFixture<BancoDeTestesFixture>
{
    // Todos os testes da coleção compartilham a API e o banco, e rodam um de cada vez.
    public const string Nome = "Api";
}

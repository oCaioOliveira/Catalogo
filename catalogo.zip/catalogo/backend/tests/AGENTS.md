# AGENTS.md — tests

Complementa o [`AGENTS.md` da raiz](../AGENTS.md). Rode `dotnet test` na raiz antes de concluir qualquer mudança.

## O que testar em cada projeto

| Projeto | Testa | Banco? | Exemplo |
|---|---|---|---|
| `Catalogo.Domain.Tests` | cada validador de tipo (válido, inválido, **limites**), `ValidadorRegistro`, `ValidadorDependencias`, `CalculadoraChaveUnica`, `SincronizadorRegistro`, **plano de exclusão** e **interpretação de filtros** | não | `Exclusao/PlanejadorExclusaoTests.cs` |
| `Catalogo.Application.Tests` | fluxo dos casos de uso com **dublês** escritos à mão (`Dubles/`), sem biblioteca de mock | não | `CasosDeUso/CriarRegistroTests.cs` |
| `Catalogo.ArchitectureTests` | regra de dependência (NetArchTest), pacotes proibidos, Central Package Management, ausência de migrations e de SQL escrito à mão | não | `DependenciasEntreCamadasTests.cs` |
| `Catalogo.Api.IntegrationTests` | HTTP de ponta a ponta com `WebApplicationFactory`, mapeamento do EF e erros reais do SQL Server | **sim** | `RegistrosApiTests.cs` |

Use os atalhos de `Apoio/TesteDeApi` (`Criar`, `Ler`, `Atualizar`, `Excluir`, `ListarOk`, `ComVersao`...)
em vez de montar requisições à mão. Para outros perfis: `var (usuario, cliente) = await CriarUsuarioAsync("m", Perfil.Interno, [EquipePadrao]);`
(token gerado direto, sem login). `EquipeDosAtalhos` define em que equipe os atalhos criam registros por equipe.
Testes de permissão usam `Postar(cliente, entidade, corpo)`, que envia o corpo exatamente como está.
Nos testes de Application, troque `_ambiente.Usuario` para testar outros perfis.

Regra prática: a regra é do motor? Teste no Domain. A regra depende de outro registro (referência,
dependência, unicidade)? Teste na Application **e** cubra o caminho feliz e um erro na integração.

## Banco de testes e Respawn

- Os testes de integração usam o banco **`ListagemGenerica_Testes`**, no mesmo container do banco
  de desenvolvimento. Ele é criado e atualizado pelo `db-init` (`database/docker`) com os mesmos scripts e o mesmo seed.
- A connection string vem de `ConnectionStrings:CatalogoTestes`, no user-secrets deste projeto ou na
  variável de ambiente `ConnectionStrings__CatalogoTestes` (ver [README](../README.md#testes)).
- Por segurança, a `BancoDeTestesFixture` **recusa** qualquer banco cujo nome não termine em `_Testes`.
- Antes de **cada** teste, o Respawn apaga os dados: `Registro`, `RegistroReferencia`, `RegistroValor`,
  `RegistroChaveUnica`, `HistoricoAlteracao`, `ConfiguracaoEntidadeEquipe`, as quatro tabelas de avaliação (`ModeloAvaliacao`,
  `CriterioAvaliacao`, `Avaliacao`, `AvaliacaoResposta`), `UsuarioEquipe`, `Usuario` e `Equipe`.
  Por isso todo teste começa com a aprovação **desligada** e **sem modelo de avaliação** em todas as entidades. Depois, a `TesteDeApi`
  cria a `EquipePadrao` e um ADMINISTRADOR, que é o `Cliente` padrão.
  Tabela de dados nova? Inclua em `BancoDeTestesFixture.TabelasDeDados`.
  Os metadados do seed ficam. Por isso os testes podem contar com o grupo `testes_desempenho`.
- Todos os testes de integração estão na coleção `"Api"` (herdam de `Apoio/TesteDeApi`) e rodam um de cada vez.
- Nunca crie metadados nos testes de integração. Se precisar de outro cenário, ele começa por um script em `database/scripts/`.

## Nomenclatura

- Classe: `<ClasseTestada>Tests` (ex.: `CriarRegistroTests`), na mesma pasta relativa da classe testada.
- Método: `Metodo_Cenario_ResultadoEsperado`, em português. Ex.:
  `Validar_TextoUmCaractereAcimaDoLimite_DevolveErroComTamanho`,
  `Post_ComunidadeComMesmoNomeComAcentoECaixaDiferentes_Devolve409`.
- Teste que cobre uma regra de negócio cita o id num comentário (`// RN09`) ou no nome.
  Os ids estão em [`docs/regras-de-negocio.md`](../../docs/regras-de-negocio.md).
- Asserts do próprio xUnit (`Assert.Equal`, `Assert.Single`...). FluentAssertions ≥ 8 é proibido.
- Um comportamento por teste. Use `[Theory]` + `[InlineData]` para variações do mesmo comportamento (ex.: limites).

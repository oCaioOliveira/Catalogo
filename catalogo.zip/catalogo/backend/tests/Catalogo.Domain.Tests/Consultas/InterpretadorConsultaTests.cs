using Catalogo.Domain.Aprovacao;
using Catalogo.Domain.Consultas;
using Catalogo.Domain.Excecoes;
using Catalogo.Domain.Metadados;
using Catalogo.Domain.Tests.Apoio;

namespace Catalogo.Domain.Tests.Consultas;

// RN17 (paginação), RN18 (filtros) e RN19 (ordenação).
public class InterpretadorConsultaTests
{
    private readonly Campo _nome = Metadado.Campo("nome", TipoDado.Texto, tamanhoMaximo: 100, ordem: 1);
    private readonly Campo _descricao = Metadado.Campo("descricao", TipoDado.TextoLongo, ordem: 2);
    private readonly Campo _numero = Metadado.Campo("numero", TipoDado.Inteiro, ordem: 3);
    private readonly Campo _vazao = Metadado.Campo("vazao", TipoDado.Decimal, precisao: 18, escala: 2, ordem: 4);
    private readonly Campo _data = Metadado.Campo("data", TipoDado.Data, ordem: 5);
    private readonly Campo _execucao = Metadado.Campo("execucao", TipoDado.DataHora, ordem: 6);
    private readonly Campo _ativo = Metadado.Campo("ativo", TipoDado.Booleano, ordem: 7);
    private readonly Campo _metodo = Metadado.Campo("metodo", TipoDado.Lista, opcoes: ["GET", "POST"], ordem: 8);
    private readonly Campo _projeto = Metadado.Campo("projeto", TipoDado.Referencia, entidadeReferenciadaId: Guid.NewGuid(), ordem: 9);
    private readonly Campo _antigo = Metadado.Campo("antigo", TipoDado.Texto, tamanhoMaximo: 10, ordem: 10, ativo: false);

    private Entidade Entidade => Metadado.Entidade([_nome, _descricao, _numero, _vazao, _data, _execucao, _ativo, _metodo, _projeto, _antigo]);

    [Fact]
    public void Interpretar_SemParametros_UsaPadroes()
    {
        var consulta = Interpretar();

        Assert.Empty(consulta.Condicoes);
        Assert.Equal(new Paginacao(1, 20), consulta.Paginacao);
        Assert.Equal(Ordenacao.Padrao, consulta.Ordenacao);
        Assert.True(consulta.Ordenacao.Descendente);
        Assert.Equal(CampoSistema.CriadoEm, consulta.Ordenacao.CampoSistema);
    }

    [Theory]
    [InlineData("1", 1)]
    [InlineData("100", 100)]   // limite
    public void Interpretar_TamanhoDentroDoLimite_Aceita(string tamanho, int esperado)
    {
        Assert.Equal(esperado, Interpretar(("tamanho", tamanho)).Paginacao.Tamanho);
    }

    [Theory]
    [InlineData("tamanho", "101", "no máximo 100")]
    [InlineData("tamanho", "0", "maior ou igual a 1")]
    [InlineData("pagina", "0", "maior ou igual a 1")]
    [InlineData("pagina", "-1", "maior ou igual a 1")]
    [InlineData("pagina", "abc", "número inteiro")]
    public void Interpretar_PaginacaoInvalida_DevolveErroNoParametro(string parametro, string valor, string trecho)
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar((parametro, valor)));

        Assert.Contains(trecho, Assert.Single(erro.Erros[parametro]));
    }

    [Fact]
    public void Paginacao_CalculaPularETotalDePaginas()
    {
        var paginacao = new Paginacao(3, 20);

        Assert.Equal(40, paginacao.Pular);
        Assert.Equal(3, paginacao.TotalPaginas(57));
        Assert.Equal(0, paginacao.TotalPaginas(0));
    }

    [Theory]
    [InlineData("nome", "nome", null, "Ana")]                  // igual, todos os tipos
    [InlineData("nome.contem", "nome", Comparacao.Contem, "an")]
    [InlineData("descricao.contem", "descricao", Comparacao.Contem, "x")]
    [InlineData("metodo", "metodo", null, "POST")]
    public void Interpretar_FiltroDeTexto_Aceita(string parametro, string campo, Comparacao? comparacao, string valor)
    {
        var condicao = Assert.Single(Interpretar((parametro, valor)).Condicoes);

        Assert.Equal(campo, condicao.Campo.Chave);
        Assert.Equal(comparacao ?? Comparacao.Igual, condicao.Comparacao);
        Assert.Equal(valor, condicao.Texto);
    }

    [Theory]
    [InlineData("numero", Comparacao.Igual, "42", 42)]
    [InlineData("numero.de", Comparacao.MaiorOuIgual, "-5", -5)]
    [InlineData("vazao.ate", Comparacao.MenorOuIgual, "9.5", 9.5)]
    public void Interpretar_FiltroNumerico_ConverteParaNumero(string parametro, Comparacao comparacao, string valor, double esperado)
    {
        var condicao = Assert.Single(Interpretar((parametro, valor)).Condicoes);

        Assert.Equal(comparacao, condicao.Comparacao);
        Assert.Equal((decimal)esperado, condicao.Numero);
    }

    [Fact]
    public void Interpretar_FiltroDeData_UsaAMeiaNoite()
    {
        var condicao = Assert.Single(Interpretar(("data.de", "2026-10-01")).Condicoes);

        Assert.Equal(new DateTime(2026, 10, 1), condicao.Data);
        Assert.Equal(Comparacao.MaiorOuIgual, condicao.Comparacao);
    }

    [Fact]
    public void Interpretar_DataHoraComSoAData_AteIncluiODiaInteiro()
    {
        // "ate=2026-10-31" num DATA_HORA = antes de 01/11 00:00 UTC.
        var condicao = Assert.Single(Interpretar(("execucao.ate", "2026-10-31")).Condicoes);

        Assert.Equal(Comparacao.Menor, condicao.Comparacao);
        Assert.Equal(new DateTime(2026, 11, 1), condicao.Data);
    }

    [Fact]
    public void Interpretar_DataHoraIgualComSoAData_ViraIntervaloDoDia()
    {
        var condicoes = Interpretar(("execucao", "2026-10-21")).Condicoes;

        Assert.Equal(2, condicoes.Count);
        Assert.Contains(condicoes, c => c.Comparacao == Comparacao.MaiorOuIgual && c.Data == new DateTime(2026, 10, 21));
        Assert.Contains(condicoes, c => c.Comparacao == Comparacao.Menor && c.Data == new DateTime(2026, 10, 22));
    }

    [Fact]
    public void Interpretar_DataHoraComFuso_ConverteParaUtc()
    {
        var condicao = Assert.Single(Interpretar(("execucao.de", "2026-10-21T14:30:00-03:00")).Condicoes);

        Assert.Equal(new DateTime(2026, 10, 21, 17, 30, 0), condicao.Data);
    }

    [Fact]
    public void Interpretar_FiltrosDeBooleanoEReferencia_ConvertemOValor()
    {
        var projeto = Guid.NewGuid();

        var condicoes = Interpretar(("ativo", "true"), ("projeto", projeto.ToString())).Condicoes;

        Assert.Equal(true, condicoes.Single(c => c.Campo == _ativo).Booleano);
        Assert.Equal(projeto, condicoes.Single(c => c.Campo == _projeto).Referencia);
    }

    [Fact]
    public void Interpretar_VariosFiltros_CombinamComE()
    {
        var consulta = Interpretar(("nome.contem", "a"), ("numero.de", "1"), ("numero.ate", "9"));

        Assert.Equal(3, consulta.Condicoes.Count);
    }

    [Theory]
    [InlineData("numero.contem", "1")]      // contem só em texto
    [InlineData("nome.de", "a")]             // de/ate só em números e datas
    [InlineData("metodo.contem", "PO")]      // LISTA só aceita igual
    [InlineData("projeto.de", "x")]
    [InlineData("ativo.ate", "true")]
    public void Interpretar_OperadorInvalidoParaOTipo_DevolveErroComOsOperadoresAceitos(string parametro, string valor)
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar((parametro, valor)));

        Assert.Contains("não é aceito", Assert.Single(erro.Erros[parametro]));
    }

    [Fact]
    public void Interpretar_OperadorDesconhecido_DevolveErro()
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar(("nome.parecido", "a")));

        Assert.Contains("desconhecido", Assert.Single(erro.Erros["nome.parecido"]));
    }

    [Theory]
    [InlineData("numero", "1.5")]
    [InlineData("numero", "abc")]
    [InlineData("vazao.de", "1,5")]          // vírgula não: cultura invariante
    [InlineData("data", "21/10/2026")]
    [InlineData("execucao.de", "2026-10-21T14:30")]   // data e hora sem fuso
    [InlineData("ativo", "sim")]
    [InlineData("metodo", "PUT")]            // fora das opções
    [InlineData("projeto", "nao-e-guid")]
    [InlineData("nome", "   ")]              // vazio
    public void Interpretar_ValorQueNaoConverteParaOTipo_DevolveErro(string parametro, string valor)
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar((parametro, valor)));

        Assert.True(erro.Erros.ContainsKey(parametro));
    }

    [Theory]
    [InlineData("nao_existe")]
    [InlineData("antigo")]   // campo inativo
    public void Interpretar_ChaveDesconhecidaOuInativa_DevolveErro(string chave)
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar((chave, "x")));

        Assert.Contains("desconhecido", Assert.Single(erro.Erros[chave]));
    }

    [Theory]
    [InlineData("id")]
    [InlineData("versao")]
    [InlineData("criadoEm.de")]
    [InlineData("criadoPor")]
    public void Interpretar_ChaveReservadaComoFiltro_DevolveErro(string parametro)
    {
        // RN14
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar((parametro, "2026-01-01")));

        Assert.Contains("reservada", Assert.Single(erro.Erros[parametro]));
    }

    [Fact]
    public void Interpretar_VariosProblemas_DevolveTodosOsErrosJuntos()
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar(
            ("tamanho", "500"), ("nao_existe", "1"), ("numero.contem", "1"), ("data", "ontem"), ("ordenacao", "descricao")));

        Assert.Equal(["data", "nao_existe", "numero.contem", "ordenacao", "tamanho"], erro.Erros.Keys.Order());
    }

    [Theory]
    [InlineData("numero", "numero", false)]
    [InlineData("-vazao", "vazao", true)]
    [InlineData("execucao", "execucao", false)]
    public void Interpretar_OrdenacaoPorCampo_RespeitaOSinal(string valor, string campo, bool descendente)
    {
        var ordenacao = Interpretar(("ordenacao", valor)).Ordenacao;

        Assert.Equal(campo, ordenacao.Campo!.Chave);
        Assert.Equal(descendente, ordenacao.Descendente);
    }

    [Theory]
    [InlineData("atualizadoEm", CampoSistema.AtualizadoEm, false)]
    [InlineData("-criadoEm", CampoSistema.CriadoEm, true)]
    public void Interpretar_OrdenacaoPorColunaDeSistema_Aceita(string valor, CampoSistema campo, bool descendente)
    {
        var ordenacao = Interpretar(("ordenacao", valor)).Ordenacao;

        Assert.Equal(campo, ordenacao.CampoSistema);
        Assert.Equal(descendente, ordenacao.Descendente);
    }

    [Theory]
    [InlineData("descricao", "TEXTO_LONGO")]
    [InlineData("-projeto", "REFERENCIA")]
    public void Interpretar_OrdenacaoPorTextoLongoOuReferencia_DevolveErro(string valor, string tipo)
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar(("ordenacao", valor)));

        Assert.Contains(tipo, Assert.Single(erro.Erros["ordenacao"]));
    }

    [Fact]
    public void Interpretar_FiltroEquipeId_ViraFiltroDeEquipeENaoCondicao()
    {
        // RN27
        var equipe = Guid.NewGuid();

        var consulta = Interpretar(("equipeId", equipe.ToString()));

        Assert.Equal(equipe, consulta.FiltroEquipe);
        Assert.Empty(consulta.Condicoes);
        Assert.Null(consulta.EquipesPermitidas);   // escopo de segurança nunca vem da URL
    }

    [Fact]
    public void Interpretar_FiltroEquipeIdInvalidoOuEmEntidadeGlobal_DevolveErro()
    {
        Assert.Throws<ValidacaoRegistroException>(() => Interpretar(("equipeId", "x")));

        var global = new Entidade
        {
            Id = Guid.NewGuid(), GrupoId = Guid.Empty, Chave = "g", Nome = "Global", Campos = [], EscopoEquipe = false,
        };
        var erro = Assert.Throws<ValidacaoRegistroException>(() =>
            InterpretadorConsulta.Interpretar(global, [KeyValuePair.Create("equipeId", Guid.NewGuid().ToString())]));
        Assert.Contains("global", erro.Erros["equipeId"][0]);
    }

    [Theory]
    [InlineData("PENDENTE", SituacaoAprovacao.Pendente)]
    [InlineData("rejeitado", SituacaoAprovacao.Rejeitado)]
    public void Interpretar_FiltroSituacaoAprovacao_ViraFiltroDeSituacao(string valor, SituacaoAprovacao esperado)
    {
        // RN37
        var consulta = Interpretar(("situacaoAprovacao", valor));

        Assert.Equal(esperado, consulta.FiltroSituacao);
        Assert.Empty(consulta.Condicoes);
        Assert.Null(consulta.NaoAprovadosSomenteDoAutor);   // escopo de segurança nunca vem da URL
    }

    [Fact]
    public void Interpretar_FiltroSituacaoAprovacaoInvalido_DevolveErro()
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar(("situacaoAprovacao", "ANALISE")));

        Assert.True(erro.Erros.ContainsKey("situacaoAprovacao"));
    }

    [Fact]
    public void Interpretar_ParametroDePaginacaoRepetido_DevolveErro()
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => Interpretar(("pagina", "1"), ("pagina", "2")));

        Assert.Contains("uma única vez", erro.Erros["pagina"][0]);
    }

    [Fact]
    public void Interpretar_ValorComCaracteresDeSql_EhApenasTexto()
    {
        // O valor nunca vira SQL: é só o texto que a Infrastructure passa como parâmetro.
        var condicao = Assert.Single(Interpretar(("nome", "' OR 1=1 --")).Condicoes);

        Assert.Equal("' OR 1=1 --", condicao.Texto);
    }

    // ---- RN48: ordenação e filtro pela média de um critério de avaliação ----

    private static readonly IReadOnlySet<string> Criterios = new HashSet<string> { "qualidade", "clareza" };

    [Theory]
    [InlineData("avaliacao.qualidade", false)]
    [InlineData("-avaliacao.qualidade", true)]
    public void Interpretar_OrdenacaoPorAvaliacao_ViraOrdenacaoPeloCriterio(string ordenacao, bool descendente)
    {
        // RN48
        var consulta = InterpretarComCriterios(("ordenacao", ordenacao));

        Assert.Equal(new Ordenacao(null, null, descendente, "qualidade"), consulta.Ordenacao);
    }

    [Theory]
    [InlineData("4", Comparacao.MaiorOuIgual, "3.95")]     // exibida >= 4.0  ⇔  média >= 3.95
    [InlineData("3.5", Comparacao.MaiorOuIgual, "3.45")]
    [InlineData("3.55", Comparacao.MaiorOuIgual, "3.55")]  // exibida >= 3.55 ⇔ exibida >= 3.6 ⇔ média >= 3.55
    public void Interpretar_FiltroAvaliacaoDe_LimiteSobreAMediaExibida(string valor, Comparacao comparacao, string limite)
    {
        // RN48: o filtro vale para a média como a API mostra (uma casa decimal).
        var condicao = Assert.Single(InterpretarComCriterios(("avaliacao.qualidade.de", valor)).CondicoesAvaliacao!);

        Assert.Equal(new CondicaoAvaliacao("qualidade", comparacao, decimal.Parse(limite, System.Globalization.CultureInfo.InvariantCulture)), condicao);
        Assert.Empty(InterpretarComCriterios(("avaliacao.qualidade.de", valor)).Condicoes);
    }

    [Fact]
    public void Interpretar_FiltroAvaliacaoAte_ViraMenorQueOLimite()
    {
        // exibida <= 3  ⇔  média < 3.05
        var condicao = Assert.Single(InterpretarComCriterios(("avaliacao.clareza.ate", "3")).CondicoesAvaliacao!);

        Assert.Equal(new CondicaoAvaliacao("clareza", Comparacao.Menor, 3.05m), condicao);
    }

    [Theory]
    [InlineData("avaliacao.inexistente.de", "4", "desconhecido")]
    [InlineData("avaliacao.qualidade", "4", "avaliacao.qualidade.de")]   // igualdade não existe
    [InlineData("avaliacao.qualidade.contem", "4", "avaliacao.qualidade.de")]
    [InlineData("avaliacao.qualidade.de", "6", "de 1 a 5")]
    [InlineData("avaliacao.qualidade.de", "quatro", "de 1 a 5")]
    public void Interpretar_FiltroAvaliacaoInvalido_DevolveErroNoParametro(string parametro, string valor, string trecho)
    {
        var erro = Assert.Throws<ValidacaoRegistroException>(() => InterpretarComCriterios((parametro, valor)));

        Assert.Contains(trecho, Assert.Single(erro.Erros[parametro]));
    }

    [Fact]
    public void Interpretar_AvaliacaoSemModeloAtivo_ExplicaQueNaoHaCriterios()
    {
        // Sem modelo ativo (lista vazia), "avaliacao.x" é erro tanto na ordenação quanto no filtro.
        var erro = Assert.Throws<ValidacaoRegistroException>(() =>
            Interpretar(("ordenacao", "-avaliacao.qualidade"), ("avaliacao.qualidade.de", "4")));

        Assert.Contains("não tem modelo de avaliação ativo", erro.Erros["ordenacao"][0]);
        Assert.Contains("não tem modelo de avaliação ativo", erro.Erros["avaliacao.qualidade.de"][0]);
    }

    private ConsultaRegistros InterpretarComCriterios(params (string Chave, string Valor)[] parametros) =>
        InterpretadorConsulta.Interpretar(Entidade, parametros.Select(p => KeyValuePair.Create(p.Chave, p.Valor)), Criterios);

    private ConsultaRegistros Interpretar(params (string Chave, string Valor)[] parametros) =>
        InterpretadorConsulta.Interpretar(Entidade, parametros.Select(p => KeyValuePair.Create(p.Chave, p.Valor)));
}

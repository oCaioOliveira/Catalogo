-- Cria o login/usuário listagem_app, usado pela APLICAÇÃO (nunca use o sa na aplicação).
-- Permissões: ler, gravar e executar procedures. NÃO pode alterar o schema.
-- Idempotente: se o login já existe, apenas sincroniza a senha com o .env.
-- Variáveis sqlcmd: $(DB_NAME), $(APP_DB_PASSWORD)

USE [master];
GO

IF SUSER_ID(N'listagem_app') IS NULL
BEGIN
    PRINT 'Criando login listagem_app...';
    CREATE LOGIN [listagem_app] WITH PASSWORD = N'$(APP_DB_PASSWORD)',
        DEFAULT_DATABASE = [$(DB_NAME)], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
END
ELSE
BEGIN
    PRINT 'Login listagem_app já existe; sincronizando senha.';
    ALTER LOGIN [listagem_app] WITH PASSWORD = N'$(APP_DB_PASSWORD)';
END
GO

USE [$(DB_NAME)];
GO

IF DATABASE_PRINCIPAL_ID(N'listagem_app') IS NULL
BEGIN
    PRINT 'Criando usuário listagem_app no banco $(DB_NAME)...';
    CREATE USER [listagem_app] FOR LOGIN [listagem_app] WITH DEFAULT_SCHEMA = [dbo];
END
GO

-- ADD MEMBER e GRANT são seguros de repetir.
ALTER ROLE [db_datareader] ADD MEMBER [listagem_app];
ALTER ROLE [db_datawriter] ADD MEMBER [listagem_app];
GRANT EXECUTE TO [listagem_app];
GO

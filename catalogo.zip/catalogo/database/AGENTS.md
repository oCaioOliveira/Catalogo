# AGENTS.md — database

Complementa o [`AGENTS.md` da raiz](../AGENTS.md). O passo a passo do Docker local (subir, resetar,
conectar) está em [`database/README.md`](README.md). A decisão está em
[`docs/adr/0003`](../docs/adr/0003-schema-por-scripts-sql.md).

## Scripts versionados

- O schema é definido **só** pelos scripts `scripts/V<numero>__<descricao>.sql`, aplicados em ordem de número.
- A tabela `dbo.__VersaoSchema` registra cada script aplicado. Um script com número já registrado **não roda de novo**.
- **Script aplicado em produção é imutável.** Nunca edite nem renomeie um `V00x` existente,
  inclusive o `V001`. Precisa corrigir algo? Crie o próximo script.

## Como criar um `V00x`

1. Crie `scripts/V002__descricao_curta.sql` com o **próximo** número, 3 dígitos e **dois** sublinhados.
   O `aplicar_scripts.sh` recusa nome fora do padrão e número repetido.
2. Escreva SQL de SQL Server puro, que rode **igual no SSMS**:
   - nada de `USE`, nome de banco, caminho de arquivo ou senha no script;
   - separe lotes com `GO` (ex.: depois de `CREATE TABLE` e antes de usar a tabela, e em `CREATE VIEW`/`PROCEDURE`);
   - variáveis `$(...)` do sqlcmd não são substituídas;
   - dê nome a toda constraint (`PK_`, `FK_`, `UQ_`, `CK_`, `DF_`, `IX_`), seguindo o V001. O EF e o tradutor de erros dependem desses nomes.
3. Prefira scripts que possam rodar de novo sem erro (`IF OBJECT_ID(...) IS NULL`, `IF NOT EXISTS`).
   Se um script falhar no meio, os lotes anteriores ao erro **ficam** no banco.
4. Aplique localmente nos dois bancos (desenvolvimento e testes):
   `cd database/docker && docker compose --env-file ../.env run --rm db-init`.
   O comando precisa terminar com código 0.
5. Atualize o mapeamento do EF (ver [`backend/src/Catalogo.Infrastructure/AGENTS.md`](../backend/src/Catalogo.Infrastructure/AGENTS.md))
   e [`docs/modelo-de-dados.md`](../docs/modelo-de-dados.md). Rode `dotnet test` de dentro de `backend/`.
6. Mudou metadados (uma listagem nova, um campo novo)? Atualize ou crie o documento em `docs/listagens/`.
7. O script altera `Registro.Dados`? Atualize `RegistroValor` no **mesmo** script: as duas tabelas
   andam sempre juntas ([ADR 0013](../docs/adr/0013-registro-valor.md)). O `V002` mostra como carregar
   `RegistroValor` a partir do JSON com `OPENJSON`.
8. Nenhum campo pode usar chave reservada (`id`, `versao`, `criadoEm`, `atualizadoEm`, `equipeId`,
   `criadoPor`, `atualizadoPor`, `situacaoAprovacao`, `ultimaDecisao`, `avaliacao`, `pagina`, `tamanho`, `ordenacao`, `busca`, `dependeDe`): a aplicação recusa os metadados ([RN14](../docs/regras-de-negocio.md#rn14--chaves-reservadas)).

9. Entidade nova: defina `EscopoEquipe` (1 = por equipe, o padrão; 0 = global) no mesmo script e
   registre a decisão no documento da listagem (RN27).
10. Nunca exclua linhas de `Usuario`, `Equipe` ou `HistoricoAlteracao` num script: usuários e equipes são
   desativados, e o histórico é permanente (RN31, RN32).
11. Valor novo num CHECK do histórico (`Operacao`, `AlvoTipo`)? Recrie o CHECK num script novo, como o `V004`,
   e atualize os conversores em `Domain/Historico` e o texto do CHECK em `HistoricoAlteracaoConfiguracao`.
12. Registros inseridos por script nascem **APROVADO** (padrão da coluna `SituacaoAprovacao`, V004).
13. Índice **filtrado** (`WHERE ...`), coluna computada ou view indexada exigem `SET QUOTED_IDENTIFIER ON;` no início do
   script (o `sqlcmd` usa OFF). Veja o `V005`.
14. O seed não cria modelos de avaliação: avaliação é configuração de cada equipe, feita pela API (RN40).

## Permissões

- A aplicação usa **só** o login `listagem_app` (`db_datareader`, `db_datawriter`, `EXECUTE`).
  Ele **não** consegue `CREATE`/`ALTER`/`DROP`: se a aplicação precisar mudar o schema, o caminho
  certo é um script.
- O `sa` só administra o banco local. Nunca o use em connection string da aplicação.
- Senhas ficam em `database/.env` (fora do git), nunca nos arquivos versionados.

## Produção

- Não há Docker em produção. O DBA aplica **os mesmos arquivos** de `scripts/`, em ordem, à mão
  (SSMS ou `sqlcmd -b -i`), e registra cada um em `dbo.__VersaoSchema` (Versao, ArquivoNome).
- Conferir antes de aplicar: `SELECT * FROM dbo.__VersaoSchema ORDER BY Versao;`.
- A collation do servidor de produção precisa ser a mesma de `MSSQL_COLLATION` (hoje `Latin1_General_CI_AI`).
  A normalização da unicidade (RN09) pressupõe CI_AI.

# Regras de negócio do motor

Cada regra tem um identificador (**RN01**, **RN02**...). Cite o identificador:

- no código, em comentários onde a regra é aplicada (ex.: `// RN09`);
- nos testes, no nome ou num comentário;
- nos PRs, quando a mudança mexer numa regra.

Mudou uma regra? Atualize **este arquivo no mesmo PR**. Nunca reaproveite um número: uma regra
removida fica marcada como *(removida)*.

| Id | Regra | Onde está |
|---|---|---|
| [RN01](#rn01--campos-desconhecidos) | Campos desconhecidos são recusados | `ValidadorRegistro` |
| [RN02](#rn02--campos-inativos) | Campos inativos não podem ser preenchidos | `ValidadorRegistro`, `EntidadeMapeamentos` |
| [RN03](#rn03--obrigatoriedade) | Obrigatoriedade (nulo e texto em branco = vazio) | `ValidadorRegistro` |
| [RN04](#rn04--validação-e-normalização-por-tipo) | Validação e normalização por tipo | `Validacao/Tipos/*` |
| [RN05](#rn05--todos-os-erros-de-uma-vez) | Todos os erros de uma vez, por campo | `ValidadorRegistro`, `ErrosPorCampo`, `PreparadorRegistro` |
| [RN06](#rn06--referências-existem-e-são-da-entidade-certa) | Referências existem e são da entidade certa | `PreparadorRegistro` |
| [RN07](#rn07--referências-fora-do-json) | Referências ficam fora do JSON | `ValidadorRegistro`, `SincronizadorRegistro`, `RegistroMapeamentos` |
| [RN08](#rn08--campos-dependentes) | Campos dependentes | `ValidadorDependencias` |
| [RN09](#rn09--unicidade) | Unicidade por hash normalizado | `CalculadoraChaveUnica`, `PreparadorRegistro` |
| [RN10](#rn10--nulo-não-gera-chave-única) | Nulo não gera chave única | `CalculadoraChaveUnica` |
| [RN11](#rn11--ações-de-exclusão-restringir-e-cascata) | Ações de exclusão: RESTRINGIR e CASCATA | `PlanejadorExclusao`, banco (FK) |
| [RN12](#rn12--concorrência-otimista) | Concorrência otimista | `AtualizarRegistro`, `UnidadeDeTrabalho` |
| [RN13](#rn13--colunas-de-sistema) | Colunas de sistema não são campos | `Registro`, `RegistroDto` |
| [RN14](#rn14--chaves-reservadas) | Chaves reservadas | `ChavesReservadas`, `MetadadosProvider` |
| [RN15](#rn15--atualização-substitui-o-registro-inteiro) | Atualização substitui o registro inteiro | `AtualizarRegistro`, `SincronizadorRegistro` |
| [RN16](#rn16--plano-de-exclusão) | Plano de exclusão | `PlanejadorExclusao`, `ExcluirRegistro` |
| [RN17](#rn17--paginação) | Paginação | `InterpretadorConsulta`, `Paginacao` |
| [RN18](#rn18--filtros) | Filtros | `InterpretadorConsulta`, `ConsultaRegistrosLinq` |
| [RN19](#rn19--ordenação) | Ordenação | `InterpretadorConsulta`, `ConsultaRegistrosLinq` |
| [RN20](#rn20--rótulo-das-referências) | Rótulo das referências | `MontadorRegistroDto`, `ConversorValorTipado` |
| [RN21](#rn21--opções-de-campo-dependente) | Opções de campo dependente | `ListarOpcoes` |
| [RN22](#rn22--limites-do-decimal) | Limites do DECIMAL | `CK_Campo_Decimal` (V002) |
| [RN23](#rn23--autenticação) | Autenticação por matrícula e senha | `Login`, `ProvedorIdentidadeLocal`, `VerificacaoUsuarioMiddleware` |
| [RN24](#rn24--bloqueio-por-tentativas) | Bloqueio por tentativas | `Usuario.RegistrarFalhaDeLogin` |
| [RN25](#rn25--senha-e-troca-obrigatória) | Senha e troca obrigatória | `PoliticaSenha`, `TrocarSenha`, `VerificacaoUsuarioMiddleware` |
| [RN26](#rn26--matriz-de-permissões) | Matriz de permissões | `PoliticaPermissao` |
| [RN27](#rn27--registros-globais-e-por-equipe) | Registros globais e por equipe | `Entidade.EscopoEquipe`, `PoliticaPermissao.ResolverEquipe` |
| [RN28](#rn28--registro-de-outra-equipe-é-404) | Registro de outra equipe é 404 | `PoliticaPermissao.Decidir`, `Permissoes.Exigir` |
| [RN29](#rn29--isolamento-de-referências-entre-equipes) | Isolamento de referências entre equipes | `PoliticaPermissao.PodeReferenciar`, `PreparadorRegistro` |
| [RN30](#rn30--último-administrador) | Último administrador | `RegrasAdministrador` |
| [RN31](#rn31--usuários-e-equipes-não-são-excluídos) | Usuários e equipes não são excluídos | `AlterarAtivacaoUsuario`, `AlterarAtivacaoEquipe` |
| [RN32](#rn32--histórico-de-alterações) | Histórico de alterações | `ServicoHistorico`, `ComparadorAlteracoes` |
| [RN33](#rn33--aprovação-ativável-por-entidade-e-equipe) | Aprovação ativável por entidade e equipe | `DefinirConfiguracaoAprovacao`, `PoliticaPermissao.PodeConfigurarEquipe` |
| [RN34](#rn34--situação-de-aprovação-e-criação) | Situação de aprovação e criação | `FluxoAprovacao.SituacaoInicial`, `PoliticaPermissao.Decidir` |
| [RN35](#rn35--alteração-e-reenvio-pelo-externo) | Alteração e reenvio pelo EXTERNO | `PoliticaPermissao.Decidir`, `FluxoAprovacao.SituacaoAposAlteracao` |
| [RN36](#rn36--decisão-aprovar-ou-rejeitar) | Decisão: aprovar ou rejeitar | `DecidirAprovacao`, `FluxoAprovacao.Decidir`, `ListarPendentes` |
| [RN37](#rn37--visibilidade-de-registros-não-aprovados) | Visibilidade de registros não aprovados | `PoliticaPermissao.PodeVer`, `ConsultaRegistrosLinq` |
| [RN38](#rn38--referências-a-registros-não-aprovados) | Referências a registros não aprovados | `PoliticaPermissao.PodeReferenciarSituacao`, `PreparadorRegistro`, `ListarOpcoes` |
| [RN39](#rn39--unicidade-e-exclusão-de-registros-não-aprovados) | Unicidade e exclusão de registros não aprovados | `PreparadorRegistro`, `PoliticaPermissao.Decidir` |
| [RN40](#rn40--quem-configura-os-modelos-de-avaliação) | Quem configura os modelos de avaliação | `PoliticaPermissao.PodeConfigurarEquipe`, `ConfiguracaoDaEquipe` |
| [RN41](#rn41--um-modelo-ativo-por-entidade-e-equipe) | Um modelo ativo por entidade e equipe | `CriarModeloAvaliacao`, `AlterarAtivacaoModeloAvaliacao`, `UX_ModeloAvaliacao_Ativo` (V005) |
| [RN42](#rn42--critérios-tipos-e-comentário) | Critérios: tipos e comentário | `RegrasModeloAvaliacao.Validar` |
| [RN43](#rn43--alterar-um-modelo-que-já-tem-avaliações) | Alterar um modelo que já tem avaliações | `RegrasModeloAvaliacao.ValidarAlteracao`, `RegrasAvaliacao.AplicarRespostas` |
| [RN44](#rn44--quem-avalia-e-o-que-pode-ser-avaliado) | Quem avalia e o que pode ser avaliado | `PoliticaPermissao.PodeAvaliar`, `RegrasAvaliacao.PodeSerAvaliado`, `AvaliarRegistro` |
| [RN45](#rn45--uma-avaliação-por-usuário-item-e-modelo) | Uma avaliação por usuário, item e modelo | `AvaliarRegistro`, `UQ_Avaliacao_Registro_Modelo_Usuario` (V005) |
| [RN46](#rn46--validação-das-respostas) | Validação das respostas | `RegrasAvaliacao.ValidarRespostas` |
| [RN47](#rn47--resumo-e-visibilidade-das-avaliações) | Resumo e visibilidade das avaliações | `ListarAvaliacoesRegistro`, `AvaliacaoRepository`, `PoliticaPermissao.PodeVerAvaliacoesIndividuais` |
| [RN48](#rn48--avaliação-no-registro-e-na-listagem) | Avaliação no registro e na listagem | `MontadorRegistroDto`, `InterpretadorConsulta`, `ConsultaRegistrosLinq` |

---

## RN01 — Campos desconhecidos

Toda chave enviada no JSON precisa ser a `Chave` de um campo da entidade. A comparação é **exata**
(diferencia maiúsculas): `"Nome"` não é o campo `nome`.
Erro no campo enviado: *"Campo desconhecido na entidade 'X'."*

## RN02 — Campos inativos

Campo com `Ativo = 0` continua no banco (os dados antigos são preservados), mas:

- enviar um valor para ele gera o erro *"Campo inativo: não pode mais ser preenchido."*;
- ele não aparece em `GET /entidades`, e o front não deve mostrá-lo.

## RN03 — Obrigatoriedade

Um campo conta como **vazio** quando está ausente, é `null` ou é um texto só com espaços.

- Campo vazio com `Obrigatorio = 1` → *"Campo obrigatório."*
- Campo vazio opcional → ignorado, e **não** é gravado no JSON.

## RN04 — Validação e normalização por tipo

Cada `TipoDado` tem um validador (padrão Strategy, `backend/src/Catalogo.Domain/Validacao/Tipos`). Ele
confere o valor **e o normaliza**: o valor gravado é sempre o normalizado. Os tipos JSON são
estritos, então um número enviado como texto (`"42"`) é recusado.

| Tipo | Aceita | Grava (normalizado) |
|---|---|---|
| `TEXTO` | texto JSON com até `TamanhoMaximo` caracteres, contados **depois** do trim | texto sem espaços nas pontas |
| `TEXTO_LONGO` | texto JSON de qualquer tamanho | texto sem espaços nas pontas |
| `INTEIRO` | número inteiro de 32 bits (-2147483648 a 2147483647), sem casas decimais | o número |
| `DECIMAL` | número com até `Escala` casas decimais (zeros à direita não contam) e até `Precisao − Escala` dígitos antes da vírgula | o número com exatamente `Escala` casas (`12.5` → `12.50`) |
| `BOOLEANO` | `true` ou `false` (não aceita `"true"`, `0` nem `1`) | `true`/`false` |
| `DATA` | ISO 8601 `aaaa-mm-dd` (ex.: `"2026-10-21"`) | igual |
| `DATA_HORA` | ISO 8601 **com fuso** (ex.: `"2026-10-21T14:30:00-03:00"` ou `"...Z"`). Sem fuso é recusado, porque não dá para saber o instante | em UTC: `"2026-10-21T17:30:00Z"` |
| `LISTA` | exatamente uma das `Opcoes` (diferencia maiúsculas) | igual |
| `REFERENCIA` | GUID no formato `D` (`3f2504e0-4f89-11d3-9a0c-0305e82c3301`). Aqui só se confere o formato; existência é RN06 | GUID em minúsculas |

## RN05 — Todos os erros de uma vez

A validação **não para no primeiro erro**. A resposta 400 traz todos os erros, agrupados por chave de campo:

```json
{
  "title": "Um ou mais campos são inválidos.",
  "status": 400,
  "errors": {
    "campo_inexistente": ["Campo desconhecido na entidade 'Sigla'."],
    "codigo_sigla": ["Deve ter no máximo 20 caracteres (foram informados 30)."],
    "comunidade": ["Campo obrigatório."]
  }
}
```

São duas etapas: primeiro RN01 a RN04 (sem banco); se passarem, RN06 e RN08 (com banco), cujos erros também voltam juntos.

## RN06 — Referências existem e são da entidade certa

Cada GUID num campo `REFERENCIA` precisa ser o id de um registro **existente** e da entidade
indicada em `Campo.EntidadeReferenciadaId`. Caso contrário: *"Registro {id} não encontrado."* ou
*"O registro {id} não é da entidade 'Projeto'."*. O banco garante o mesmo com FKs compostas. A
aplicação confere antes para dar uma mensagem amigável.

## RN07 — Referências fora do JSON

Campos `REFERENCIA` **nunca** são gravados em `Registro.Dados`: vão para `RegistroReferencia`, com
integridade garantida pelo banco. Para o cliente o registro é plano: as referências aparecem em
`dados` junto com os campos simples, como GUID. Ver [modelo-de-dados.md](modelo-de-dados.md#como-um-campo-vira-dado).

## RN08 — Campos dependentes

Uma `CampoDependencia` diz: **"em `Campo`, só vale escolher registros cujo `CampoAlvo` seja igual
ao valor de `CampoOrigem`"**.

- `CampoVia` nulo: `CampoOrigem` é um campo do **próprio** registro.
- `CampoVia` preenchido: segue essa referência (um salto) e lê `CampoOrigem` no registro apontado.

Exemplo do seed: em `cenario_teste`, o `endpoint_servico` escolhido precisa ser do mesmo `projeto`
do `relatorio_teste` escolhido.

| Coluna | Valor |
|---|---|
| `CampoId` | `cenario_teste.endpoint_servico` |
| `CampoViaId` | `cenario_teste.relatorio_teste` |
| `CampoOrigemId` | `relatorio_teste.projeto` |
| `CampoAlvoId` | `endpoint_servico.projeto` |

Regras de aplicação:

- campo dependente vazio → nada a conferir;
- valor de origem vazio → sem filtro, aceita qualquer registro;
- origem preenchida e alvo diferente (ou vazio) → erro no **campo dependente**.

A mesma regra servirá para o front filtrar as opções do select (endpoint fora do escopo desta etapa).

## RN09 — Unicidade

Uma `RestricaoUnica` (simples ou composta) impede dois registros da mesma entidade com os mesmos
valores normalizados. Funcionamento ([adr/0005](adr/0005-unicidade-por-hash.md)):

1. Cada valor é normalizado para texto:
   - **TEXTO, TEXTO_LONGO e LISTA**: trim, sem acentos e em maiúsculas (cultura invariante). Assim `"Comunidade Ágil"` = `"  COMUNIDADE AGIL"`, coerente com a collation `Latin1_General_CI_AI`;
   - **INTEIRO**: cultura invariante;
   - **DECIMAL**: cultura invariante, com a escala do campo (`12.5` → `"12.50"`);
   - **BOOLEANO**: `"true"`/`"false"`;
   - **DATA**: `aaaa-mm-dd`;
   - **DATA_HORA**: ISO 8601 em UTC;
   - **REFERENCIA**: GUID em minúsculas, formato `D`.
2. Os textos são unidos, **na ordem dos campos da restrição** (`Campo.Ordem`, depois `Chave`),
   pelo separador `\u001f`.
3. O resultado em UTF-8 vai para o SHA-256, gravado em `RegistroChaveUnica`.

**Nas entidades por equipe (RN27), a unicidade vale dentro de cada equipe**: o id da equipe entra
como primeira parte do texto do hash. Duas equipes podem ter um projeto "Portal" cada, e um 409 nunca
revela que existe um registro de outra equipe (RN28). Nas entidades globais, vale para o sistema todo.

A aplicação confere antes de gravar (409 com mensagem amigável), e o UNIQUE
(`RestricaoUnicaId`, `ValorHash`) do banco garante a regra mesmo com gravações simultâneas. Se
o banco barrar (erros 2601/2627), a resposta também é 409.

> ⚠️ Mudar a normalização muda os hashes. Os registros já gravados precisariam de um script para recalcular.

## RN10 — Nulo não gera chave única

Se **qualquer** campo de uma restrição estiver vazio, a chave dessa restrição não é gerada. É a
mesma semântica do UNIQUE do SQL: nulo não conflita com nada. Exemplo: `uq_link_rtc` só vale para
links que têm RTC.

## RN11 — Ações de exclusão: RESTRINGIR e CASCATA

Todo campo `REFERENCIA` tem uma `AcaoExclusao`, que diz o que acontece ao excluir o registro **apontado**:

- **RESTRINGIR**: a exclusão é bloqueada enquanto houver registros apontando para ele. O banco já
  garante isso: `FK_RegistroReferencia_Destino` não tem cascade.
- **CASCATA**: os registros que apontam para ele são excluídos junto. **A aplicação** faz isso,
  excluindo os filhos antes, na mesma transação. Ex.: excluir um `relatorio_teste` exclui os seus
  `cenario_teste` e `link`.

Ao excluir um registro, o banco apaga em cascata as **suas próprias** linhas de `RegistroReferencia`
e `RegistroChaveUnica` (`ON DELETE CASCADE`).

Como a exclusão é montada, passo a passo, está em [RN16](#rn16--plano-de-exclusão).

## RN12 — Concorrência otimista

`Registro.Versao` é um `rowversion`: o SQL Server muda o valor a cada UPDATE. O GET devolve a
`versao` (em Base64), e o PUT a envia de volta **no corpo**, junto com os campos
([ADR 0009](adr/0009-concorrencia-pela-versao-no-corpo.md)):

```json
PUT .../registros/{id}
{ "versao": "AAAAAAAAB9I=", "nome": "Comunidade Ágil" }
```

- `versao` ausente ou inválida → **400** na chave `versao`.
- `versao` diferente da atual → **409** (`ConflitoConcorrenciaException`), sem gravar nada.
- A proteção continua até a gravação: o UPDATE é `... WHERE Versao = @versaoLida`. Se alguém
  gravar entre a leitura e o UPDATE, a resposta também é **409**.

## RN13 — Colunas de sistema

`id`, `criadoEm`, `atualizadoEm` e `versao` são colunas do `Registro`, preenchidas pelo sistema, e
não são cadastradas como `Campo` (RN14). Na resposta elas ficam fora do objeto `dados`. No corpo do
POST e do PUT, que é plano, são ignoradas (o PUT lê a `versao`). Datas de sistema são sempre UTC.

## RN14 — Chaves reservadas

Nenhum `Campo` pode ter como `Chave` (sem diferenciar maiúsculas):

| Chaves | Por quê |
|---|---|
| `id`, `versao`, `criadoEm`, `atualizadoEm`, `equipeId`, `criadoPor`, `atualizadoPor`, `situacaoAprovacao`, `ultimaDecisao`, `avaliacao` | colunas de sistema do registro: o corpo traz a `versao` (PUT) e o `equipeId` (POST) junto com os campos |
| `pagina`, `tamanho`, `ordenacao`, `busca`, `dependeDe` | parâmetros da listagem e das opções: um campo com esse nome não poderia ser filtrado na URL |

Um metadado assim é erro de configuração: o carregamento dos metadados do grupo falha com uma
mensagem que lista os campos inválidos (o endpoint responde 500 e o log mostra a mensagem).
No corpo do POST/PUT, as colunas de sistema não são campos: o PUT lê a `versao`, o POST lê o `equipeId`
(RN27) e as demais são ignoradas (a situação só muda pela decisão, RN36, e a avaliação tem endpoints próprios, RN45). Na listagem, `equipeId` e `situacaoAprovacao`
(RN37) são filtros, e `avaliacao.<critério>` é prefixo de filtro e de ordenação (RN48); as demais chaves reservadas como filtro dão **400**.

## RN15 — Atualização substitui o registro inteiro

`PUT .../registros/{id}` recebe **todos** os campos ([ADR 0008](adr/0008-atualizacao-via-put.md)):

- campo opcional **ausente** (ou nulo, ou texto em branco) = campo **removido**, do JSON, das
  referências, dos valores tipados e, se fizer parte de uma restrição, da chave única (RN10);
- vale a **mesma validação do criar** (RN01 a RN09);
- o registro **não conflita consigo mesmo** na unicidade: manter o próprio valor é permitido;
- `atualizadoEm` recebe a data e hora atual (UTC) e a resposta traz a nova `versao`.

## RN16 — Plano de exclusão

`DELETE .../registros/{id}` faz exclusão **física** ([ADR 0010](adr/0010-exclusao-fisica-com-plano.md)).
Antes de apagar qualquer coisa, monta um **plano**:

1. Busca quem aponta para o registro (`RegistroReferencia.RegistroDestinoId`).
2. Para cada referência, olha a `AcaoExclusao` do campo:
   - **CASCATA**: quem aponta entra no plano, e o passo 1 se repete para ele;
   - **RESTRINGIR**: **bloqueia**, a menos que quem aponta também já esteja no plano.
3. Cada registro é visitado uma vez só (ciclos não travam o processo).
4. **Tudo ou nada**: um bloqueio em qualquer nível impede a exclusão de tudo. A resposta é **409**
   com a lista do que impede:
   ```json
   { "title": "Exclusão bloqueada.", "status": 409,
     "dependencias": [ { "entidade": "endpoint_servico", "campo": "projeto", "quantidade": 2,
                         "exemplos": ["cadastro", "consulta"] } ] }
   ```
   `exemplos` traz até 5 rótulos (RN20); sem rótulo, o id.
5. Plano válido: exclui **dos filhos para o pai**, numa única transação, e responde **204**. Ao
   excluir um registro, o banco apaga junto as referências que **saem** dele, as chaves únicas e os
   valores tipados (CASCADE). As referências que **chegam** nele não têm CASCADE, por isso a ordem
   importa. Num ciclo (A → B → A), a referência que fecha o ciclo é apagada antes.

Exemplo: excluir um `relatorio_teste` exclui os seus `cenario_teste` e `link` (CASCATA), mas não o
`rtc` nem o `endpoint_servico` para os quais eles apontam.

## RN17 — Paginação

`GET .../registros` devolve uma página ([ADR 0012](adr/0012-paginacao-por-pagina.md)):

```json
{ "itens": [ ... ], "pagina": 1, "tamanho": 20, "total": 57, "totalPaginas": 3 }
```

- `pagina`: a partir de 1 (padrão 1). Página além da última devolve `itens` vazio.
- `tamanho`: de 1 a **100** (padrão 20). Fora disso, **400**.
- `total` conta todos os registros que passam nos filtros.

## RN18 — Filtros

Os demais parâmetros da URL são filtros, no formato `<chave>` ou `<chave>.<operador>`, e se
combinam com **E**:

| Operador | Tipos | Exemplo |
|---|---|---|
| (nenhum) = igual | todos | `metodo=POST`, `projeto=<guid>`, `ativo=true` |
| `contem` | TEXTO, TEXTO_LONGO | `nome_servico.contem=pix` |
| `de` / `ate` (inclusivos) | INTEIRO, DECIMAL, DATA, DATA_HORA | `data_execucao.de=2026-10-01` |

- Os valores seguem os formatos de RN04 (decimal com ponto, data `aaaa-mm-dd`, GUID formato `D`,
  `true`/`false`). LISTA precisa ser uma das opções.
- **DATA_HORA** aceita data e hora com fuso (instante exato) **ou só a data**. Só a data = o **dia
  inteiro em UTC**: `data_execucao=2026-10-21` pega o dia todo, e `ate=2026-10-31` vai até 23:59:59 de 31/10.
- Igualdade e `contem` em texto **não diferenciam maiúsculas nem acentos** (collation do banco).
  `%`, `_` e `[` são buscados literalmente.
- REFERENCIA filtra pela tabela `RegistroReferencia`; os demais tipos, pela `RegistroValor` (ADR 0013).
- Erros (todos juntos, **400**, no formato de RN05, com a chave = nome do parâmetro):
  - chave desconhecida ou de campo inativo;
  - chave reservada (RN14);
  - operador desconhecido ou inválido para o tipo;
  - valor que não converte para o tipo.
- Filtro pela média de um critério de avaliação: `avaliacao.<criterio>.de` / `.ate` (RN48).

## RN19 — Ordenação

`ordenacao=<chave>` (crescente) ou `ordenacao=-<chave>` (decrescente). A chave é de um campo, ou
`criadoEm`/`atualizadoEm`. O padrão é `-criadoEm` (mais recentes primeiro).

- A ordem respeita o tipo: números como números (9.5 antes de 10), datas como datas.
- Não é possível ordenar por TEXTO_LONGO nem por REFERENCIA (**400**).
- Registros sem valor no campo vêm primeiro na ordem crescente. Empates são desfeitos pelo `id`,
  para a paginação ser estável.
- `ordenacao=[-]avaliacao.<criterio>` ordena pela média de um critério de avaliação, com os itens sem nota
  **sempre por último** (RN48).

## RN20 — Rótulo das referências

Em **todo** retorno de registro (GET por id, listagem, POST e PUT), cada referência vem como
`{ "id": "<guid>", "rotulo": "<texto>" }`. Na entrada (POST e PUT), a referência continua sendo só o GUID.

- O rótulo é o valor do **campo de exibição** (`Entidade.CampoExibicaoId`) do registro apontado,
  convertido em texto no mesmo formato do JSON (ex.: `35.50`, `2026-10-21T17:30:00Z`, `true`).
- `rotulo` é **nulo** se a entidade apontada não tem campo de exibição, se ele é REFERENCIA, ou se está vazio no registro.
- Os rótulos são buscados **em lote**: uma consulta para todos os registros da resposta, nunca uma por linha.

## RN21 — Opções de campo dependente

`GET .../entidades/{entidade}/campos/{campo}/opcoes` devolve, no formato de RN17, itens
`{ "id", "rotulo" }` ordenados por rótulo, para o front montar o select de um campo **REFERENCIA**
(outro tipo: **400**).

| Parâmetro | Uso |
|---|---|
| `busca` | trecho do rótulo (`contem`, sem diferenciar maiúsculas nem acentos). Exige rótulo texto. |
| `pagina`, `tamanho` | como em RN17 |
| `dependeDe` | o valor de que o campo depende |
| `equipeId` | a equipe do registro do formulário (que pode ainda não existir). Mesma regra do POST (RN27): obrigatório para o administrador e para quem está em várias equipes |

- **Sem `CampoDependencia`**: todos os registros da entidade referenciada.
- **Com `CampoDependencia`** (RN08), `dependeDe` é **obrigatório** (400 se faltar):
  - com `CampoVia`: `dependeDe` é o id do registro escolhido **no campo via** (ex.: o relatório do
    cenário). O valor de origem é lido em `CampoOrigem` desse registro;
  - sem `CampoVia`: `dependeDe` já é o valor de `CampoOrigem` no formulário;
  - as opções são os registros cujo `CampoAlvo` aponta para esse valor de origem. Origem vazia = sem filtro (RN08).
- O `GET .../entidades` informa, em cada campo, `dependeDe`: a chave do campo do formulário cujo
  valor o front envia. Ex.: em `cenario_teste.endpoint_servico`, `dependeDe = "relatorio_teste"`.
- **Limitações desta versão** (respondem 400 com a explicação): `CampoOrigem` e `CampoAlvo`
  precisam ser REFERENCIA, e a entidade referenciada precisa ser do mesmo grupo.
- As opções são só as **visíveis para a equipe do registro**: os registros dessa equipe ou globais (RN29).
- É só conveniência: o POST e o PUT continuam validando a dependência no servidor (RN08).

## RN22 — Limites do DECIMAL

Um campo DECIMAL pode ter no máximo **10 casas decimais** (`Escala <= 10`) e **28 dígitos antes da
vírgula** (`Precisao - Escala <= 28`), para caber em `RegistroValor.ValorNumero decimal(38,10)`.
Garantido pelo CHECK `CK_Campo_Decimal`, recriado no script `V002`.

## RN23 — Autenticação

Todo endpoint exige login, exceto `POST /api/auth/login` e `GET /health`. Detalhes técnicos em
[seguranca.md](seguranca.md).

- `POST /api/auth/login` com `{ matricula, senha }` devolve um **JWT** (8 horas por padrão, sem refresh token).
- A matrícula não diferencia maiúsculas.
- Qualquer falha (matrícula inexistente, senha errada, usuário inativo ou bloqueado) responde
  **401** com a **mesma** mensagem: *"Matrícula ou senha inválidas."*. Nunca se revela se a matrícula existe.
- No máximo 10 tentativas de login por minuto por endereço IP (configurável). Acima disso, **429**.
- O token só identifica a pessoa. Perfil, equipes e situação são lidos do banco a cada requisição,
  com cache de até 1 minuto. Desativar um usuário, trocar o perfil ou as equipes vale **na hora**
  quando feito pela API (o cache é descartado), ou em até 1 minuto se feito direto no banco.
- Usuário desativado com token ainda válido recebe **401** na próxima requisição.
- Sem token ou com token inválido/expirado: **401**.

## RN24 — Bloqueio por tentativas

- **5** senhas erradas seguidas bloqueiam o login por **15 minutos**, mesmo com a senha certa.
- Login certo zera a contagem. Depois que o bloqueio vence, a contagem recomeça do zero.
- A redefinição de senha pelo administrador também desbloqueia.

## RN25 — Senha e troca obrigatória

- **Política**: pelo menos 10 caracteres, com letra e número. A nova senha tem que ser diferente da atual.
- Senha nunca é registrada em log, devolvida pela API ou gravada no histórico. No banco fica só o hash (PBKDF2).
- Usuário criado pelo administrador, ou com senha redefinida, recebe uma **senha provisória** gerada pelo
  sistema (16 caracteres), devolvida **uma única vez**, e `DeveTrocarSenha = 1`.
- Com `DeveTrocarSenha = 1`, o login funciona, mas todos os outros endpoints respondem **403** com
  `"codigo": "TROCA_DE_SENHA_OBRIGATORIA"`. As exceções são `POST /api/auth/trocar-senha` (`{ senhaAtual, novaSenha }`)
  e `GET /api/auth/eu`, que o front usa para saber que precisa pedir a troca.

## RN26 — Matriz de permissões

Cada usuário tem **um** perfil, que vale em todas as equipes dele ([ADR 0014](adr/0014-perfil-unico-por-usuario.md)).
"Suas equipes" são as equipes **ativas** às quais ele pertence.

| Perfil | Ver | Criar | Alterar | Excluir | Escopo |
|---|---|---|---|---|---|
| EXTERNO | ✅ | ❌ | ❌ | ❌ | suas equipes e registros globais |
| INTERNO | ✅ | ✅ | ✅ | ❌ | ver: suas equipes e globais; escrever: só nas suas equipes |
| GESTOR | ✅ | ✅ | ✅ | ✅ | ver: suas equipes e globais; escrever e excluir: só nas suas equipes |
| ADMINISTRADOR | ✅ | ✅ | ✅ | ✅ | qualquer equipe e registros globais, sem precisar pertencer a elas |

- A regra fica num lugar só: `PoliticaPermissao` (Domain). Os casos de uso perguntam a ela.
- Perfil sem permissão para a operação num registro que ele **vê**: **403**.
- Listagem e opções aplicam o escopo **dentro da consulta**: o não-administrador vê a união das suas
  equipes mais os globais. Todos podem filtrar por `equipeId`; o não-administrador, só entre as suas (senão, 403).
- Usuários e equipes (`/api/usuarios`, `/api/equipes`) são administrados só pelo ADMINISTRADOR (403 para os demais).
- Na exclusão em cascata (RN16), **todos** os registros do plano precisam estar dentro do que o usuário
  pode excluir (senão, 403 e nada é excluído).
- Avaliar itens e configurar modelos de avaliação (RN40, RN44, RN47) também são regras da `PoliticaPermissao`.
- A tabela acima vale para as entidades **sem aprovação**. Com a aprovação ativa numa entidade e equipe
  (RN33), o EXTERNO passa a criar e a alterar o que criou (RN34, RN35), e GESTOR e ADMINISTRADOR decidem
  (RN36). Tudo isso está na **mesma** `PoliticaPermissao`, que recebe a situação e o autor do registro.

## RN27 — Registros globais e por equipe

A `Entidade` define o escopo dos seus registros ([ADR 0017](adr/0017-escopo-global-ou-por-equipe-na-entidade.md)):

- **Por equipe** (`EscopoEquipe = 1`, o padrão): cada registro pertence a uma equipe (`Registro.EquipeId`),
  que **não muda** depois de criado. Um `equipeId` diferente no PUT dá 400.
- **Global** (`EscopoEquipe = 0`): tabelas de apoio compartilhadas. Todos os perfis veem; **só o
  ADMINISTRADOR** cria, altera ou exclui.

Equipe na criação, pela chave reservada `equipeId` no corpo do POST:

| Situação | `equipeId` |
|---|---|
| Entidade global | não aceito (400) |
| Usuário de **uma** equipe | opcional: se ausente, é a dele |
| Usuário de **várias** equipes, ou ADMINISTRADOR | **obrigatório** (400 se faltar) |
| Não-administrador informando equipe da qual não participa | 403 |
| Administrador informando equipe inexistente ou inativa | 400 |

A classificação das entidades de Testes de Desempenho está em
[listagens/testes-desempenho.md](listagens/testes-desempenho.md#escopo-das-entidades-a-confirmar) e **ainda precisa ser confirmada** com o negócio.

## RN28 — Registro de outra equipe é 404

Um registro que o usuário **não pode ver** é tratado como **inexistente**: **404**, com a mesma
mensagem de um id que não existe. Isso vale para GET, PUT, DELETE e histórico, e também quando um
POST/PUT aponta para ele (*"Registro ... não encontrado."*). Assim a API não revela que o registro
existe ([ADR 0019](adr/0019-404-para-registro-de-outra-equipe.md)).

## RN29 — Isolamento de referências entre equipes

- Um registro de uma equipe só referencia registros **da mesma equipe** ou **globais**.
- Um registro global só referencia registros globais.
- A regra é sobre os **registros**, não sobre o usuário: vale **mesmo que ele pertença às duas equipes**.
  O POST e o PUT respondem 400 no campo (*"O registro ... é de outra equipe"*).
- As opções de campo (RN21) listam só o que o registro do formulário pode referenciar.
- Consequência: uma exclusão em cascata nunca atravessa equipes.

## RN30 — Último administrador

Não é possível desativar nem rebaixar o **último** administrador ativo: **409** com
`"codigo": "ULTIMO_ADMINISTRADOR"`. O primeiro administrador é criado pelo comando `criar-admin`, que só
funciona se não houver nenhum administrador ativo (ver o [README do back-end](../backend/README.md)).

## RN31 — Usuários e equipes não são excluídos

- Usuários e equipes **nunca são excluídos**, só desativados (`PATCH .../ativacao`), para preservar o histórico.
- Usuário **não-administrador** precisa de pelo menos **uma equipe ativa** (400 ao criar ou alterar sem
  ela). O administrador não precisa de equipe.
- Não é possível desativar uma equipe que é a **única equipe ativa** de algum usuário ativo não-administrador:
  **409** com `"codigo": "USUARIOS_SEM_EQUIPE"`. Mova esses usuários para outra equipe antes.
- Vínculos com equipes desativadas são ignorados nas permissões.

## RN32 — Histórico de alterações

Toda criação, alteração e exclusão de **registro**, **usuário** e **equipe**, toda **decisão** de aprovação
(operações `APROVACAO` e `REJEICAO`, RN36), toda mudança de **configuração** de aprovação (alvo `CONFIGURACAO`, RN33),
de **modelo de avaliação** (alvo `MODELO_AVALIACAO`, RN40) e de **avaliação** (alvo `AVALIACAO`, RN45) grava uma linha em
`HistoricoAlteracao` ([ADR 0018](adr/0018-historico-explicito-no-caso-de-uso.md)):

- no **mesmo SaveChanges** da operação: se o histórico falhar, a operação inteira falha;
- uma linha por alvo. Numa exclusão em cascata, uma linha por registro excluído, todas com o mesmo `CorrelacaoId`;
- com `DadosAntes` e `DadosDepois`, o objeto **plano**:
  - para registros, os campos no formato do corpo do POST, com referências como GUID;
  - para usuários, `matricula`, `nome`, `perfil`, `ativo` e `equipes`;
  - para equipes, `nome` e `ativa`;
  - para decisões, `situacaoAprovacao` antes e depois, e a **justificativa** numa coluna própria;
  - para configurações, `requerAprovacao`;
  - para modelos de avaliação, `modelo` (id), `nome`, `descricao`, `ativo` e uma chave por critério (`criterios.qualidade`);
  - para avaliações, `avaliacao` (id), `modelo` (nome) e uma chave por resposta (`qualidade.estrelas`, `qualidade.comentario`, `observacoes.texto`);
  - na criação, `DadosAntes` é nulo; na exclusão, `DadosDepois` é nulo;
- para usuários, **nunca** contém senha nem hash. Troca e redefinição de senha aparecem como o campo
  `senha` com `"alterada"` ou `"redefinida"`, sem valor;
- o registro guarda `criadoPor` e `atualizadoPor`, devolvidos como `{ id, matricula, nome }`.

Consulta, do mais recente para o mais antigo, paginada:

| Rota | Quem pode |
|---|---|
| `GET .../registros/{id}/historico` | quem pode **ver** o registro. Se ele já foi excluído, vale a equipe gravada no histórico |
| `GET /api/usuarios/{id}/historico`, `GET /api/equipes/{id}/historico` | só ADMINISTRADOR |
| `GET /api/equipes/{equipeId}/configuracoes/grupos/{grupo}/entidades/{entidade}/aprovacao/historico` | quem pode configurar (RN33) |
| `GET /api/equipes/{equipeId}/configuracoes/grupos/{grupo}/entidades/{entidade}/avaliacao/historico` | quem pode configurar (RN40) |
| `GET .../registros/{id}/avaliacoes/historico` | INTERNO, GESTOR e ADMINISTRADOR que veem o registro (RN47); funciona para registro excluído |

Cada item traz quem, quando, a operação, a `justificativa` (só nas decisões) e a lista de **mudanças por campo** (`campo`, `de`, `para`),
calculada a partir do antes e do depois. Em campos REFERENCIA, `de` e `para` vêm como `{ id, rotulo }`,
com o rótulo **atual** (nulo se o registro apontado não existe mais).

Não geram histórico: login, contagem de tentativas e último acesso.

## RN33 — Aprovação ativável por entidade e equipe

A aprovação é ligada **por entidade e por equipe**, na tabela `ConfiguracaoEntidadeEquipe`
([ADR 0020](adr/0020-aprovacao-por-entidade-e-equipe.md)). Sem linha na tabela, a aprovação está **desligada**,
e tudo funciona como na RN26.

`GET` e `PUT /api/equipes/{equipeId}/configuracoes/grupos/{grupo}/entidades/{entidade}/aprovacao`, com `{ "ativa": true }`:

| Quem | Resultado |
|---|---|
| ADMINISTRADOR | configura qualquer equipe |
| GESTOR | configura as suas equipes; nas outras, **404** (como a RN28) |
| INTERNO, EXTERNO | **403** |

- Só entidades **por equipe** (RN27) têm aprovação. Entidade global: **400** no campo `entidade`.
- **Desativar** com registros PENDENTES nessa entidade e equipe: **409** com `"codigo": "APROVACOES_PENDENTES"`
  e `"quantidade"`. Decida os pendentes antes. Registros REJEITADOS não impedem a desativação: continuam
  rejeitados e, sem aprovação, o EXTERNO não os altera mais.
- Toda mudança gera histórico (RN32). Um PUT que não muda nada não gera.
- `GET .../grupos/{grupo}/entidades?equipeId=...` devolve `requerAprovacao` por entidade (sem `equipeId`, vem nulo;
  nas globais, `false`). O não-administrador só consulta as suas equipes (403 nas outras).

## RN34 — Situação de aprovação e criação

Todo registro tem uma `situacaoAprovacao`: **PENDENTE**, **APROVADO** ou **REJEITADO**. Os registros
anteriores à aprovação e os de entidades sem aprovação são APROVADO.

| Quem cria, com aprovação ativa | Situação inicial |
|---|---|
| EXTERNO | **PENDENTE** |
| INTERNO, GESTOR, ADMINISTRADOR | **APROVADO** |

- Sem aprovação ativa, o EXTERNO continua sem criar (403, RN26).
- A resposta do registro traz `situacaoAprovacao` e `ultimaDecisao` (`{ decisao, justificativa, decididoPor, decididoEm }`,
  ou nulo se nunca houve decisão). `decisao` é `APROVAR` ou `REJEITAR`.

## RN35 — Alteração e reenvio pelo EXTERNO

Com aprovação ativa, o EXTERNO altera **só os registros que ele criou**, e só enquanto estão **PENDENTE** ou
**REJEITADO** (403 nos demais). Alterar um REJEITADO é um **reenvio**: o registro volta para **PENDENTE**, e a
alteração no histórico mostra a mudança de `situacaoAprovacao`. O EXTERNO **nunca exclui**.

INTERNO, GESTOR e ADMINISTRADOR alteram como na RN26, sem mudar a situação.

## RN36 — Decisão: aprovar ou rejeitar

`POST .../registros/{id}/aprovacao` com `{ "decisao": "APROVAR" | "REJEITAR", "justificativa": "..." }`:

- Decide o **GESTOR** da equipe do registro ou o **ADMINISTRADOR**. INTERNO e EXTERNO: **403**. GESTOR de outra equipe: **404**.
- `justificativa` é obrigatória, de **10 a 1000** caracteres (sem os espaços das pontas): 400 no campo.
- Só registros **PENDENTES**: nos demais, **409** com `"codigo": "REGISTRO_NAO_PENDENTE"`.
- A decisão grava quem, quando e a justificativa no registro (a `versao` muda, RN12) e gera histórico
  (`APROVACAO` ou `REJEICAO`) com a justificativa.
- Fila: `GET /api/aprovacoes/pendentes`, do **mais antigo** para o mais novo, paginada, com filtros `grupo`,
  `entidade` e `equipeId`. GESTOR vê as suas equipes (filtrar por outra: 403); ADMINISTRADOR vê todas; os demais, 403.
- Cada registro é aprovado **individualmente**: aprovar um relatório não aprova os cenários que apontam para ele.

## RN37 — Visibilidade de registros não aprovados

- O **EXTERNO** vê os registros **APROVADOS** e os **seus** (de qualquer situação). PENDENTES e REJEITADOS
  de outras pessoas são tratados como inexistentes (**404**, RN28) e não aparecem na listagem nem nas opções.
- INTERNO, GESTOR e ADMINISTRADOR veem todas as situações, dentro do seu escopo de equipe.
- O filtro fica **dentro da consulta LINQ**, como o escopo de equipe (RN26).
- A listagem aceita `situacaoAprovacao=PENDENTE|APROVADO|REJEITADO` (400 para outro valor).

## RN38 — Referências a registros não aprovados

Um registro só referencia registros **APROVADOS** ou registros não aprovados **do mesmo autor**: o autor do
registro de origem (na criação, quem cria) tem de ser quem criou o destino. Senão, **400** no campo
(*"O registro ... ainda não foi aprovado."*). Assim o EXTERNO monta um relatório e os seus cenários antes da aprovação.

As opções de campo (RN21) seguem a mesma regra, com quem está preenchendo o formulário como autor. A RN29
(mesma equipe) continua valendo.

## RN39 — Unicidade e exclusão de registros não aprovados

- Registros PENDENTES e REJEITADOS **ocupam** as chaves únicas (RN09): um segundo registro com a mesma chave
  dá 400, mesmo que o primeiro ainda não tenha sido aprovado.
- GESTOR e ADMINISTRADOR excluem registros em qualquer situação (RN16). A exclusão em cascata não olha a situação.

## RN40 — Quem configura os modelos de avaliação

Os itens podem ser **avaliados** pelos usuários, sempre o **item inteiro** (um registro). O formulário de
avaliação é um **modelo**, configurado **por entidade e por equipe**, como a aprovação (RN33)
([ADR 0021](adr/0021-avaliacao-configuravel-com-tabelas-tipadas.md)).

Rotas sob `/api/equipes/{equipeId}/configuracoes/grupos/{grupo}/entidades/{entidade}/avaliacao`:

| Método | Rota | O que faz |
|---|---|---|
| GET | `.../avaliacao` | o modelo **ativo**, com todos os critérios em ordem (404 se não há) |
| GET | `.../avaliacao/modelos` | todos os modelos, ativo e inativos (para achar o id de um inativo) |
| POST | `.../avaliacao` | cria o modelo com a lista de critérios (**201**; **409** se já há um ativo, RN41) |
| PUT | `.../avaliacao` | altera nome, descrição e a lista **inteira** de critérios, com a `versao` do GET (RN12, RN43) |
| PATCH | `.../avaliacao/ativacao` | `{ "ativo": false }` desativa o ativo; `{ "ativo": true, "modeloId": "..." }` reativa um modelo |
| GET | `.../avaliacao/historico` | histórico dos modelos (RN32) |

- Quem configura: o **GESTOR** das suas equipes (**404** nas outras) e o **ADMINISTRADOR** (qualquer equipe).
  INTERNO e EXTERNO: **403**. É a mesma regra da aprovação (`PoliticaPermissao.PodeConfigurarEquipe`).
- Só entidades **por equipe** (RN27) têm modelo. Entidade global: **400** no campo `entidade`.
- `GET .../entidades?equipeId=...` devolve, por entidade, o `modeloAvaliacao` ativo (só os critérios ativos), para
  o front montar o formulário. Sem `equipeId` ou sem modelo, vem nulo.
- Toda criação, alteração, ativação e desativação gera histórico (alvo `MODELO_AVALIACAO`).

## RN41 — Um modelo ativo por entidade e equipe

- No máximo **um** modelo **ativo** por entidade e equipe (índice único filtrado no banco). Criar ou reativar
  com outro ativo: **409** com `"codigo": "MODELO_ATIVO_EXISTENTE"` e `"modeloId"` do ativo.
- Modelos **nunca são excluídos**. **Desativado**, o modelo para de aceitar avaliações (RN44), mas as que ele
  tem continuam visíveis, **separadas**, com o nome do modelo (RN47). A equipe pode então criar outro modelo.
- A listagem de Testes de Desempenho **não usa avaliação** por enquanto: o seed não cria nenhum modelo.

## RN42 — Critérios: tipos e comentário

Cada critério tem `chave`, `nome`, `descricao`, `tipo`, `obrigatorio`, `comentario`, `tamanhoMaximoTexto`,
`ordem` e `ativo`:

| `tipo` | Resposta | `comentario` |
|---|---|---|
| `ESTRELAS` | nota inteira de **1 a 5**, mais um comentário que justifica a nota | `NENHUM` (não aceita), `OPCIONAL` ou `OBRIGATORIO` |
| `TEXTO` | texto livre | sempre `NENHUM` |

- `chave`: obrigatória, padrão `^[a-z0-9_]+$`, até 100 caracteres, **única no modelo**. Identifica o critério
  nas respostas, nas médias e na listagem (`avaliacao.qualidade`).
- `nome` obrigatório (até 150), `descricao` até 500.
- `tamanhoMaximoTexto` (padrão 2000) vale para o texto livre e para o comentário: de **1 a 4000**.
- Padrões: `obrigatorio` false, `comentario` NENHUM, `ordem` = posição na lista, `ativo` true.
- O modelo precisa de `nome` (até 150) e de **pelo menos um critério ativo**.
- Todos os erros voltam juntos (RN05), com chaves como `nome`, `criterios` e `criterios[1].tipo`.

## RN43 — Alterar um modelo que já tem avaliações

O PUT envia a lista **inteira** de critérios; eles são casados pela `chave`. Para não corromper as notas já dadas:

| Pode | Não pode (com respostas no critério) |
|---|---|
| mudar nome e descrição do modelo e dos critérios, ordem, obrigatoriedade, comentário e tamanho | **excluir** o critério (tirá-lo da lista) |
| **adicionar** critérios | **mudar o tipo** do critério |
| **desativar** um critério (`"ativo": false`) | |

- O que não pode: **400**, explicando que o critério deve ser **desativado**. Um critério **sem** respostas pode ser excluído
  ou mudar de tipo.
- Critério desativado: some do formulário e das médias; as respostas antigas ficam (e aparecem no histórico).
- Regras novas (critério novo, obrigatoriedade nova) valem só para avaliações **criadas ou editadas depois**: as antigas
  não ficam inválidas. Ao editar, a avaliação é validada pelo modelo **atual**.
- `GET .../avaliacao` informa, por critério, `possuiRespostas`, e o modelo traz `quantidadeAvaliacoes`.

## RN44 — Quem avalia e o que pode ser avaliado

- Avaliam **INTERNO, GESTOR e ADMINISTRADOR**, em itens que eles **veem** (INTERNO e GESTOR: das suas equipes;
  ADMINISTRADOR: qualquer um). Item que o usuário não vê: **404** (RN28). **EXTERNO não avalia: 403**.
- O item precisa ter um modelo **ativo** para a entidade **na equipe dele**. Senão: **400** no campo `modelo`.
- Só itens **APROVADOS** são avaliados: com a aprovação ativa (RN33), PENDENTES e REJEITADOS dão **409** com
  `"codigo": "REGISTRO_NAO_APROVADO"`. Sem aprovação ativa, os registros já são APROVADOS.
- Ordem das verificações: quem (404/403), modelo (400), situação (409), respostas (400, RN46).

## RN45 — Uma avaliação por usuário, item e modelo

- `PUT /api/grupos/{grupo}/entidades/{entidade}/registros/{id}/avaliacoes/minha` **cria** (201) ou **edita** (200) a
  avaliação do usuário logado: `{ "versao": "...", "respostas": { "qualidade": { "estrelas": 4, "comentario": "..." },
  "observacoes": { "texto": "..." } } }`. A `versao` é obrigatória **só ao editar** (RN12: versão antiga, 409).
- Cada usuário tem **uma** avaliação por item e por modelo (UNIQUE no banco). Com um modelo novo, ele pode avaliar
  de novo; a avaliação do modelo antigo fica.
- Editar substitui as respostas dos critérios **ativos**: critério ativo não enviado = resposta removida. Respostas a
  critérios desativados ficam como estão. Uma edição que não muda nada não grava nem gera histórico.
- `DELETE .../avaliacoes/minha` remove a avaliação do usuário no modelo ativo (404 se ele não avaliou).
- **Excluir o item exclui as avaliações** (CASCADE no banco). O histórico guarda o que existia: uma linha
  `EXCLUSAO` por avaliação, com o mesmo `CorrelacaoId` da exclusão do registro.
- Toda criação, edição e remoção gera histórico (alvo `AVALIACAO`, com o registro como alvo), com as respostas
  antes e depois.

## RN46 — Validação das respostas

Todos os erros juntos (RN05), com chaves `respostas.<criterio>` e `respostas.<criterio>.<propriedade>`:

| Situação | Erro |
|---|---|
| critério desconhecido ou inativo | `respostas.inexistente` |
| critério obrigatório sem resposta (ausente ou nulo) | `respostas.qualidade` |
| resposta que não é objeto, ou com propriedade desconhecida | `respostas.qualidade`, `respostas.qualidade.nota` |
| `estrelas` ausente, fora de 1 a 5, não inteira (4.5) ou não numérica ("4") | `respostas.qualidade.estrelas` |
| `comentario` num critério com `comentario = NENHUM` | `respostas.clareza.comentario` |
| `comentario` ausente (ou em branco) num critério com `comentario = OBRIGATORIO` | `respostas.qualidade.comentario` |
| `texto` vazio, só espaços, ausente ou acima de `tamanhoMaximoTexto` (o mesmo vale para o comentário) | `respostas.observacoes.texto` |

Critério opcional não enviado (ou nulo) = não respondido. Textos são gravados sem os espaços das pontas; comentário em
branco = sem comentário.

## RN47 — Resumo e visibilidade das avaliações

`GET .../registros/{id}/avaliacoes` devolve:

- `resumo`: o do modelo **ativo** (nulo se não há): `quantidadeAvaliadores` e, para cada critério `ESTRELAS` **ativo**,
  `media` (uma casa decimal, arredondada "metade para cima"; nula sem notas), `quantidade` e `distribuicao`
  (`{ "1": n, ..., "5": n }`), e `minha` (a avaliação do usuário logado, se houver);
- `resumosAnteriores`: os mesmos dados para cada modelo **inativo** que avaliou o item, identificado pelo nome;
- `avaliacoes`: as avaliações **individuais** (autor, respostas, modelo), paginadas, das mais recentes (criadas ou
  editadas) para as mais antigas.

Visibilidade:

- **Todos que veem o item** (inclusive o EXTERNO) veem os resumos.
- As avaliações individuais e o histórico delas são só para **INTERNO, GESTOR e ADMINISTRADOR**. Para o EXTERNO,
  `avaliacoes` vem **nulo** e o histórico dá **403**.
- Médias e contagens são calculadas **no banco**, em LINQ (`GroupBy`, `Average`, `Count`), sem trazer as avaliações para a memória.

## RN48 — Avaliação no registro e na listagem

- Com modelo ativo para a entidade na equipe do registro, o retorno do registro ganha
  `"avaliacao": { "medias": { "qualidade": 4.3 }, "quantidade": 3, "minha": true }`: média de cada critério `ESTRELAS`
  ativo (nula sem notas), quantas avaliações e se o usuário logado avaliou. **Sem modelo ativo, `avaliacao` é nulo** e
  nada mais muda. `avaliacao` é chave reservada (RN14).
- Listagem: `ordenacao=[-]avaliacao.<criterio>` ordena pela média, com os itens **sem nota sempre por último**.
- Listagem: `avaliacao.<criterio>.de=4` e `.ate=4` filtram pela média **como ela é exibida** (uma casa decimal): `de=4`
  inclui uma média 3.96 (exibida 4.0). Itens sem nota não passam no filtro.
- Vale para critérios `ESTRELAS` **ativos** dos modelos **ativos** nas equipes que o usuário vê. Outro critério:
  **400** no parâmetro, com a lista dos aceitos.


# Registros de decisão de arquitetura (ADR)

Cada ADR registra **uma** decisão: o contexto, o que foi decidido e as consequências.
ADR aceito não é editado. Se a decisão mudar, crie um ADR novo que **substitui** o antigo e
marque o antigo como "Substituído por NNNN".

| Nº | Decisão | Status |
|---|---|---|
| [0001](0001-modelo-generico-eav-json.md) | Modelo genérico EAV com JSON e referências em tabela própria | Aceito |
| [0002](0002-clean-architecture-enxuta.md) | Clean Architecture enxuta | Aceito |
| [0003](0003-schema-por-scripts-sql.md) | Schema por scripts SQL versionados, sem migrations | Aceito |
| [0004](0004-sem-mediatr-automapper-fluentassertions.md) | Sem MediatR, AutoMapper e FluentAssertions 8+ | Aceito |
| [0005](0005-unicidade-por-hash.md) | Unicidade por hash em RegistroChaveUnica | Aceito |
| [0006](0006-dotnet-8.md) | .NET 8, com migração pendente para o .NET 10 | Aceito |
| [0007](0007-repositorio-por-aplicacao.md) | Repositório organizado em pastas por aplicação | Aceito |
| [0008](0008-atualizacao-via-put.md) | Atualização via PUT com o registro inteiro | Aceito |
| [0009](0009-concorrencia-pela-versao-no-corpo.md) | Concorrência otimista pela `versao` no corpo do PUT | Aceito |
| [0010](0010-exclusao-fisica-com-plano.md) | Exclusão física com plano de exclusão | Aceito |
| [0011](0011-consultas-somente-linq.md) | Consultas ao banco somente via EF Core em LINQ | Aceito |
| [0012](0012-paginacao-por-pagina.md) | Paginação por página (`pagina` e `tamanho`) | Aceito |
| [0013](0013-registro-valor.md) | Tabela de valores tipados `RegistroValor` | Aceito |
| [0014](0014-perfil-unico-por-usuario.md) | Perfil único por usuário, válido em todas as equipes | Aceito |
| [0015](0015-jwt-com-provedor-de-identidade-isolado.md) | JWT com matrícula e senha local, atrás de interface para SSO | Aceito |
| [0016](0016-passwordhasher-sem-identity.md) | PasswordHasher sem o ASP.NET Core Identity completo | Aceito |
| [0017](0017-escopo-global-ou-por-equipe-na-entidade.md) | Escopo global ou por equipe definido na Entidade | Aceito |
| [0018](0018-historico-explicito-no-caso-de-uso.md) | Histórico explícito no caso de uso, sem interceptor | Aceito |
| [0019](0019-404-para-registro-de-outra-equipe.md) | 404, e não 403, para registros de outra equipe | Aceito |
| [0020](0020-aprovacao-por-entidade-e-equipe.md) | Aprovação de registros ativável por entidade e por equipe | Aceito |
| [0021](0021-avaliacao-configuravel-com-tabelas-tipadas.md) | Avaliação configurável por entidade e equipe, com tabelas relacionais tipadas | Aceito |

Modelo para um ADR novo (`NNNN-titulo-curto.md`):

```markdown
# NNNN. Título

- Status: Proposto | Aceito | Substituído por NNNN
- Data: aaaa-mm-dd

## Contexto
## Decisão
## Consequências
```
